package com.cdtskj.xt.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cdtskj.util.Pagination;


public interface IBaseDAO<T> 
{
	
	public int add(T entity);		 
	
	public void update(T entity);
	
	public void delete(Serializable entityId);
	
	 
	
	public List<T>find(Map param);		
	 
	public List<T>findExat(Map param);
	
	
	public Pagination find(Map param,Integer page, Integer rows) throws Exception;
	
	 
	
	public T get(Class<T> c, Serializable id); 
	 
	
	public List<T> getAll(Class<T> c);
	
	public void truncate(Class<T> c);
	
	
}
