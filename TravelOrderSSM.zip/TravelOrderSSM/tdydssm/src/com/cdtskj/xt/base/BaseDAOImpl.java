package com.cdtskj.xt.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
 

import com.cdtskj.util.Pagination;


import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import org.apache.ibatis.session.*;


import org.mybatis.spring.SqlSessionTemplate;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.lang.reflect.ParameterizedType;


import java.lang.Integer;

import java.lang.String;

public class BaseDAOImpl<T> implements IBaseDAO<T>
{ 
	private SqlSessionTemplate session;
	
	protected Class<T> entityClass;
	
	protected String sqlNameSpace;
	
	
	public static final String SQLID_SELECT="selectByPrimaryKey";
	
	public static final String SQLID_INSERT="insert";
	
	public static final String SQLID_UPDATE="updateByPrimaryKey";
	
	public static final String SQLID_DELETE="deleteByPrimaryKey";
	
	
	 
	
	public static final String SQLID_SELECT_PARAM="selectParam";
	
	public static final String SQLID_SELECT_COUNT="selectCount";
	
	
	
	public static final String SQLID_SELECT_EXAT="selectExat";
	
	public static final String SQLID_DELETE_PARAM="deleteParam";
	
	 
	
	

	public SqlSessionTemplate getSession() 
	{
		return session;
	}


	public void setSession(SqlSessionTemplate session) 
	{
		this.session = session;
	}


	public Class<T> getEntityClass() 
	{
		return entityClass;
	}


	public String getSqlNameSpace() 
	{
		return sqlNameSpace;
	}

	
	
	 


	protected BaseDAOImpl() 
	{
			super();
			
			this.entityClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	
			this.sqlNameSpace= this.entityClass.getName();
	}

	
	
	public int add(T entity)
	{
		int intK = 0;
		
		try
		{
			String strCmd=this.sqlNameSpace + "." + this.SQLID_INSERT;
			
			intK=session.insert(strCmd, entity);
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.add() Script error: " + ex.toString());
		}
		
		return intK;
	}
	
		
	
	public void update(T entity)
	{
		try
		{
			
			String strCmd=this.sqlNameSpace + "." + this.SQLID_UPDATE;
			
			session.update(strCmd, entity);
			
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.update() Script error: " + ex.toString());
		}		
		
	}
	
	
	
	public void delete(Serializable entityId)
	{
		try
		{
			String strCmd=this.sqlNameSpace + "." + this.SQLID_DELETE;						
			
			session.delete(strCmd, entityId);
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.delete() Script error: " + ex.toString());
		}
	}
	
	
	
	
	public List<T>find(Map param)
	{
		List<T> list=null;
		
		try
		{
			
			String strCmd=this.sqlNameSpace + "." + this.SQLID_SELECT_PARAM;						
			
			list =(List<T>) session.selectList(strCmd, param) ;
			
		}	
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
						
		return list;
	}
	
	
	public List<T>findExat(Map param)
	{
		List<T> list=null;
		
		try
		{
			 
			
			String strCmd=this.sqlNameSpace + "." + this.SQLID_SELECT_EXAT;						
			
			list =(List<T>) session.selectList(strCmd, param) ;
			
		}	
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
						
		return list;
	}
	 
	
	
	public Pagination find(Map param, Integer pageno, Integer pagesize) throws Exception
	{		 
		 
		//1.Dim variable
		
		long totalrow =(long)0;
		
		List listdata = null;
		
		int totalpage=0,nextpage=0,prepage=0;				 
		
		String strCmd="";
		
		Pagination mypg = new Pagination();
		
		
		try		
		{
		
			//2.Set pageno
			
			if(pageno ==null || pageno < 1)
			{
				pageno = 1;
			}
			
			
			//3.Set pagesize
			
			if(pagesize == null || pagesize < 1)
			{
				pagesize = 10;
			}
			
						
			//4.Get total row
			
		    strCmd=this.sqlNameSpace + "." + this.SQLID_SELECT_COUNT;						
			
			totalrow = (Long) session.selectOne(strCmd, param);
			
			
			if(totalrow < 1L)
			{				 				
				 mypg = new Pagination(0L, 0, pageno, pagesize,Collections.EMPTY_LIST,0, 0);
				 
				 return mypg;
			}
			
			
			if(totalrow % pagesize ==  0)
		    {
		    	totalpage =(int)(totalrow/pagesize);
		    }
		    else
		    {
		    
		    	totalpage =((int) (totalrow/pagesize) ) + 1;
		    }
			
			
			if(pageno > totalpage)
			{
				pageno = totalpage;
			}
			
			
			if(pageno - 1 <= 0)
			{
				prepage = 1;
			}
			else
			{
				prepage = pageno - 1 ;
			}
			
			
			if(pageno + 1 > totalpage)
			{
				nextpage = totalpage;
			}
			else
			{
				nextpage = pageno + 1 ;
			}
			
			
			//5.Get data			
			
			param.put("pageno", pageno);
			
			param.put("pagesize", pagesize);
			
			
			
			strCmd=this.sqlNameSpace + "." + this.SQLID_SELECT_PARAM;						
			
			listdata =(List<T>) session.selectList(strCmd, param) ;
			
			mypg = new Pagination(totalrow,totalpage, pageno, pagesize,listdata, prepage, nextpage);
		
		}		
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
		
		 
		return mypg;
		
	}
	
	
	
	
	
	 
	
	
	public T get(Class<T> c, Serializable entityId)
	{
		T entity = null;
		
		try
		{
			String strCmd=this.sqlNameSpace + "." + this.SQLID_SELECT;						
			
			entity= session.selectOne(strCmd, entityId);
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
		
		return entity;
	}
	
	
	
	
	
	public List<T> getAll(Class<T> c)
	{
		List<T> list=null;
		
		try
		{
			
			String strCmd=this.sqlNameSpace + "." + this.SQLID_SELECT_PARAM;						
			
			list =(List<T>) session.selectList(strCmd) ;
			
		}	
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
						
		return list;
		
	}
	
	
	
	public void truncate(Class<T> c)
	{
		try
		{
			
			String strCmd=this.sqlNameSpace + "." + this.SQLID_DELETE_PARAM;						
			
			session.delete(strCmd);
			
		}	
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
	}
	
	
}
