package com.cdtskj.xt.user.dao;

import com.cdtskj.pojo.XtUser;
import com.cdtskj.xt.base.IBaseDAO;

public interface IUserDAO  extends IBaseDAO<XtUser>
{

}
