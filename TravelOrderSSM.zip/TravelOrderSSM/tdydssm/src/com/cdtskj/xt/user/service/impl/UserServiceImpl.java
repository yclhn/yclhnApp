package com.cdtskj.xt.user.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cdtskj.pojo.XtUser;

import com.cdtskj.util.Pagination;
import com.cdtskj.xt.user.dao.IUserDAO;
import com.cdtskj.xt.user.dao.impl.UserDAOImpl;
import com.cdtskj.xt.user.service.IUserService;

public class UserServiceImpl implements IUserService
{

	private IUserDAO dao ;
	
	

	public IUserDAO getDao() 
	{
		return dao;
	}

	public void setDao(IUserDAO dao) 
	{
		this.dao = dao;
	}
	
	
	
	
	public List<XtUser> login(XtUser user)
	{
		List<XtUser> list=null;		
		String strHQL="";		
		Map param = new HashMap();
		
		
		try
		{		 
						
			param.put("loginname", user.getLoginname());
			
			param.put("password", user.getPassword());		 
			
			list = this.dao.findExat(param)	;				 
		
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.login() Script error : " + ex.toString());
		}
		
		
		return list;		
		
	}
	
	

	public void addUser(XtUser user)
	{
		try
		{			
			 this.dao.add(user);	 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("UserServiceImpl.addUser() Script error: " + ex.toString());
		}
	}
	
	
	
	public void updateUser(XtUser user)  
	{				
		try
		{
			this.dao.update(user);	 			 		 
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.updateUser() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteUser(XtUser user)
	{
		try
		{			 			 
			 this.dao.delete(user.getUserid());			 			  
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.deleteUser() Script error: " + ex.toString());
		}	
	}
	
	
	
	public XtUser queryUserById(Integer id)
	{ 
		 XtUser user=this.dao.get(XtUser.class, id);
		 
		 return user;
	}
		
	
	public Pagination queryPaginationUser(XtUser user, Integer pageno, Integer pagesize)
	{
		 
		
		Pagination mypagi = null;
		
		try
		{			
			Map param = new HashMap();
			
			param.put("name", user.getName());
			
			param.put("loginname",  user.getLoginname());
			
			mypagi = this.dao.find(param, pageno, pagesize) ;   
			
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.queryPaginationUser() Script error: " + ex.toString());
		}		
		 
		
		return mypagi;
		
	}
	
		
}
