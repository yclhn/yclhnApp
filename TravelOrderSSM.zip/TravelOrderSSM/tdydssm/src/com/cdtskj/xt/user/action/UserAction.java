package com.cdtskj.xt.user.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.XtUser;
import com.cdtskj.querypara.UserParam;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.util.PageParam;
import com.cdtskj.util.Pagination;
import com.cdtskj.xt.user.service.IUserService;
 

@RequestMapping(value="/user")

@Controller

public class UserAction  
{
	
	
	@Resource
	
	private IUserService userService;
	
	
	@Resource
	
	private IAgencyService agencyService;
	
		
	
	
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	
	public String save(XtUser user)
	{
		
		
		if (user.getUserid()!=null)
		{
			userService.updateUser(user);
		}
		else
		{
			userService.addUser(user);
		}
		
		return "forward:list.action";
	}
	
	
	
	
	@RequestMapping(value="/delete")
	
	public String delete(Integer userid)
	{
		try
		{	
			XtUser user = userService.queryUserById(userid);;
			
			userService.deleteUser(user);	
			
		}
		catch(Exception ex )
		{
			System.out.println("UserAction.delete() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";
	}
	
	
	
	
	
	
	@RequestMapping(value="/list")
	
	public String list(Map<String,Object> map)
	{
		UserParam userParam = new UserParam();
		
		XtUser user= new XtUser();
		
		PageParam  pageParam = new PageParam();
		
		
		userParam.setUser(user);
		
		userParam.setPageParam(pageParam);
		
		
		map.put("userParam", userParam);
			 
		
		return "/html/xt/user/userlist";
	}
	
	
	
	@RequestMapping(value="/addui")
	
	public String addui(Map<String,Object> map)
	{
		XtUser user=new XtUser();
		
		map.put("user", user);
		
		
		List<LyAgency> agencys = agencyService.querySuitableAgencys();		
		
		map.put("agencys", agencys);
		
		
		
		return "/html/xt/user/userdata";
	}
	
	
	
	
	@RequestMapping(value="/updateui")
	
	public String updateui(Integer userid,Map<String,Object> map)
	{				
		XtUser user = userService.queryUserById(userid);		
		
		map.put("user", user);
		
		
		List<LyAgency> agencys = agencyService.querySuitableAgencys();		
		
		map.put("agencys", agencys);				
		
		
		return "/html/xt/user/userdata";
	}
	
	
	 
	
	
	@RequestMapping(value="/query", method={RequestMethod.POST,RequestMethod.GET})
	
	public String query(UserParam userParam, Map<String,Object> map)
	{
		
		//1.Dim variable
		
		List<XtUser> list = null;
		
		Pagination mypagi = null;
		
		XtUser user = null; 
		
		PageParam pageParam= null;  
		
		Integer pageno = 0;
		
		Integer pageSize = 0;
		 		 
		
		
		try
		{
			
			//2.Get param
			
			 
			
			user = userParam.getUser();
			
			pageParam = userParam.getPageParam();
			
			
			if(pageParam != null )
			{
				
				pageno = pageParam.getPageno();
				
				//pageSize = pageParam.getPagesize();
			
			}
			
			pageSize =3;
			
			
			//3.Getdata
			
			 mypagi = userService.queryPaginationUser(user, pageno, pageSize);
			
		     map.put("mypagi",mypagi);
		     
		     map.put("user", user);
		     				
		}
		catch(Exception ex)
		{
			System.out.println("UserAction.query() Script error: " + ex.toString());			
		}
		
		return "/html/xt/user/userlist";
		
	}
	 

}
