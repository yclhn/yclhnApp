package com.cdtskj.xt.log.dao;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.xt.base.IBaseDAO;

public interface ILogDAO extends IBaseDAO<XtLog> 
{

}
