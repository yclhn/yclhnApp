package com.cdtskj.xt.log.service;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.util.Pagination;

public interface ILogService 
{

	public void addLog(XtLog log);	 
	
	public void deleteLog(XtLog Log);
	
	public void deleteAllLog();	
	
	 
	
	public Pagination queryPaginationLog(XtLog Log, Integer page, Integer rows);
	
}
