package com.cdtskj.xt.log.service.impl;

 



import java.util.HashMap;
import java.util.Map;

import com.cdtskj.pojo.XtLog;

import com.cdtskj.util.Pagination;
import com.cdtskj.xt.log.dao.ILogDAO;
import com.cdtskj.xt.log.service.ILogService;

public class LogServiceImpl implements ILogService
{
	private ILogDAO dao;
	

	public ILogDAO getDao() 
	{
		return dao;
	}

	public void setDao(ILogDAO dao) 
	{
		this.dao = dao;
	}
	
	
	
	public void addLog(XtLog log)
	{
		try
		{			  			 
			 this.dao.add(log); 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("LogServiceImpl.addLog() Script error: " + ex.toString());
		}
		
	}
	
	
 
	
	public void deleteLog(XtLog log)
	{
		try
		{			
			 this.dao.delete(log.getLogid());	 			 
		}
		catch(Exception ex)
		{
			System.out.println("LogServiceImpl.deleteLog() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void deleteAllLog()
	{
		try
		{		 			 			
			this.dao.truncate(XtLog.class);		
		}
		catch(Exception ex)
		{
			System.out.println("LogServiceImpl.deleteAllLog() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public Pagination queryPaginationLog(XtLog log, Integer pageno, Integer pagesize)
	{
		 		
		Pagination mypagi = null;
		
		try
		{		 			
			Map param = new HashMap();
			
			param.put("describes", log.getDescribes());
			
			param.put("operator", log.getOperator());
			
			 			
			mypagi = this.dao.find(param, pageno, pagesize);
			
		}
		catch(Exception ex)
		{
			System.out.println("LogServiceImpl.queryPaginationLog() Script error: " + ex.toString());
		}			 
		
		return mypagi;
		
	}
		 

}
