package com.cdtskj.xt.log.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.querypara.LogParam;
import com.cdtskj.util.PageParam;
import com.cdtskj.util.Pagination;
import com.cdtskj.xt.log.service.ILogService;
 



@RequestMapping(value="/log")

@Controller

public class LogAction   
{
	
	@Resource
	
	private ILogService logService;
	
		
	
	
	@RequestMapping(value="/delete")
	
	public String delete(Integer logid)
	{
		try
		{	
			XtLog log = new XtLog();
			
			log.setLogid(logid);
			
			logService.deleteLog(log);	
			
		}
		catch(Exception ex )
		{
			System.out.println("LogAction.delete() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";
	}
	
	
	
	
	
	
	@RequestMapping(value="/list")
	
	public String list(Map<String,Object> map)
	{
		LogParam logParam = new LogParam();
		
		XtLog log= new XtLog();
		
		PageParam  pageParam = new PageParam();
		
		
		logParam.setLog(log);
		
		logParam.setPageParam(pageParam);
		
		
		map.put("logParam", logParam);
			 
		
		return "/html/xt/log/loglist";
	}
	
	
	
	
	@RequestMapping(value="/query", method={RequestMethod.POST,RequestMethod.GET})
	
	public String query(LogParam logParam, Map<String,Object> map)
	{
		
		//1.Dim variable
		
		List<XtLog> list = null;
		
		Pagination mypagi = null;
		
		XtLog log = null; 
		
		PageParam pageParam= null;  
		
		Integer pageno = 0;
		
		Integer pageSize = 0;
		 		 
		
		
		try
		{
			
			//2.Get param			
			 
			
			log = logParam.getLog();
			
			pageParam = logParam.getPageParam();
			
			
			if(pageParam != null )
			{
				
				pageno = pageParam.getPageno();
				
				//pageSize = pageParam.getPagesize();
			
			}
			
			pageSize =3;
			
			
			//3.Getdata
			
			 mypagi = logService.queryPaginationLog(log, pageno, pageSize);
			
		     map.put("mypagi",mypagi);
		     
		     map.put("log", log);
		     				
		}
		catch(Exception ex)
		{
			System.out.println("LogAction.query() Script error: " + ex.toString());			
		}
		
		return "/html/xt/log/loglist";
		
	}
	
	
	@RequestMapping(value="/deleteall")
	
	public String deleteall()
	{
		try
		{	
			logService.deleteAllLog();			 					
		}
		catch(Exception ex )
		{
			System.out.println("LogAction.deleteall() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";	
		
	}
	
	
}
