package com.cdtskj.xt.login.action;

import com.cdtskj.pojo.XtUser;
import com.cdtskj.xt.user.service.IUserService;
import com.cdtskj.xt.user.service.impl.UserServiceImpl;
 
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

 
@RequestMapping(value="/login")

@Controller

public class LoginAction  
{
	
	@Resource
	
	private IUserService  userService ;
	
	
	@RequestMapping(value="/loginui")
	
	public String loginui(Map<String,Object> map)
	{
		XtUser user = new XtUser();
		
		map.put("user", user);
		
		return "/index";
	}
	
	
	@RequestMapping(value="/login" , method=RequestMethod.POST)
	
	public ModelAndView execute(XtUser user,HttpSession session)  
	{
		
		//1.Dim variable
		
		String strLogontime="";	
		
		List<XtUser> list=null;
		
		ModelAndView mav=null;
		
		try
		{		
			
			//2.Login
		
			list=userService.login(user);
			
			
			//3.Set session
			
			if(list.size() > 0)		 
			{				
				
				session.setAttribute("userid", user.getLoginname());
				
				SimpleDateFormat myfmt =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				Date mydt = new Date();
				
				strLogontime = myfmt.format(mydt);
				
				session.setAttribute("logontime",strLogontime );
				
				session.setAttribute("user",user );
				
				System.out.println("Log successfully, User is :" + user.getLoginname() + ", loginTime is :" + strLogontime);				
					
				mav = new ModelAndView("/main");			         
				
				return mav;
			}
			else
			{
				mav = new ModelAndView("forward:/login/loginui.action");
				
				return mav;
			}	
			
		}		
		catch(Exception ex)
		{
			System.out.println("LoginAction.execute() Script Error: " + ex.toString());
		}
		
		mav = new ModelAndView("forward:/login/loginui.action");
		
		return mav;
		
	}
	
	

}
