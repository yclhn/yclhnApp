package com.cdtskj.querypara;

import com.cdtskj.pojo.LyGuide;
import com.cdtskj.util.PageParam;

public class GuideParam 
{
	
	private LyGuide guide;
	
	private PageParam pageParam;
	
	
	

	public LyGuide getGuide() 
	{
		return guide;
	}

	public void setGuide(LyGuide guide) 
	{
		this.guide = guide;
	}

	public PageParam getPageParam() 
	{
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) 
	{
		this.pageParam = pageParam;
	}
	
	

}
