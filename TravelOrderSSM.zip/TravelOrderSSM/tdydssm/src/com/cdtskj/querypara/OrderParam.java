package com.cdtskj.querypara;

import com.cdtskj.pojo.LyOrder;
import com.cdtskj.util.PageParam;

public class OrderParam 
{
	
	private LyOrder order;
	
	private PageParam pageParam;
	

	public LyOrder getOrder() 
	{
		return order;
	}

	public void setOrder(LyOrder order) 
	{
		this.order = order;
	}

	public PageParam getPageParam() 
	{
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) 
	{
		this.pageParam = pageParam;
	}
	
}
