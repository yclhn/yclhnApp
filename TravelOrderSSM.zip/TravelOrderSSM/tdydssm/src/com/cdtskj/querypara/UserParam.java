package com.cdtskj.querypara;

import com.cdtskj.pojo.XtUser;
import com.cdtskj.util.PageParam;

public class UserParam 
{
	
	private XtUser user;
	
	private PageParam pageParam;
	
	

	public XtUser getUser() 
	{
		return user;
	}

	public void setUser(XtUser user) 
	{
		this.user = user;
	}

	public PageParam getPageParam() 
	{
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) 
	{
		this.pageParam = pageParam;
	}
	
	
	

}
