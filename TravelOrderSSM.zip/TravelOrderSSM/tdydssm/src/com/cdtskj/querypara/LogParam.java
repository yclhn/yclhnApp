package com.cdtskj.querypara;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.util.PageParam;

public class LogParam 
{
	
	private XtLog log; 
	
	private PageParam pageParam;
	
	

	public XtLog getLog() 
	{
		return log;
	}

	public void setLog(XtLog log) 
	{
		this.log = log;
	}
	

	public PageParam getPageParam() 
	{
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) 
	{
		this.pageParam = pageParam;
	}
	
	
}
