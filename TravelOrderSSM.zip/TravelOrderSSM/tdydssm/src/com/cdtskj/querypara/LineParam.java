package com.cdtskj.querypara;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.util.PageParam;

public class LineParam 
{
	
	private LyLine line;
	
	private PageParam pageParam;
	
	
	

	public LyLine getLine() 
	{
		return line;
	}

	public void setLine(LyLine line) 
	{
		this.line = line;
	}
	
	
	

	public PageParam getPageParam() 
	{
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) 
	{
		this.pageParam = pageParam;
	}
	
	
	

}
