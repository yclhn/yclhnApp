package com.cdtskj.querypara;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.util.PageParam;

public class AgencyParam 
{
	
	private LyAgency agency;
	
	private PageParam pageParam;

	public LyAgency getAgency() 
	{
		return agency;
	}

	public void setAgency(LyAgency agency) 
	{
		this.agency = agency;
	}

	public PageParam getPageParam() 
	{
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) 
	{
		this.pageParam = pageParam;
	}
	
	
	

}
