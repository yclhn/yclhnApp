package com.cdtskj.util;

public class PageParam 
{
	
	Integer pageno;
	
	Integer pagesize;

	public Integer getPageno() 
	{
		return pageno;
	}

	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}

	public Integer getPagesize() 
	{
		return pagesize;
	}

	public void setPagesize(Integer pagesize) 
	{
		this.pagesize = pagesize;
	}
	
	
	

}
