package com.cdtskj.util;

import java.util.*;

public class Pagination 
{
	
	private Long totalrow;
	
	private Integer totalpage;
	
	private Integer pageno;
	
	private Integer pagesize;
	
	private List listdata;
	
	private Integer prepage;
	
	private Integer nextpage;
	
	
	
	
	
	public Long getTotalrow() 
	{
		return totalrow;
	}



	public void setTotalrow(Long totalrow) 
	{
		this.totalrow = totalrow;
	}



	public Integer getTotalpage() 
	{
		return totalpage;
	}



	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}



	public Integer getPageno() 
	{
		return pageno;
	}



	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}



	public Integer getPagesize() 
	{
		return pagesize;
	}



	public void setPagesize(Integer pagesize) 
	{
		this.pagesize = pagesize;
	}



	public List getListdata() 
	{
		return listdata;
	}



	public void setListdata(List listdata) 
	{
		this.listdata = listdata;
	}



	public Integer getPrepage() 
	{
		return prepage;
	}



	public void setPrepage(Integer prepage) 
	{
		this.prepage = prepage;
	}



	public Integer getNextpage() 
	{
		return nextpage;
	}



	public void setNextpage(Integer nextpage) 
	{
		this.nextpage = nextpage;
	}



	public Pagination()
	{
		super();
	}
	
	
	
	public Pagination(Long totalrow,Integer totalpage, Integer pageno, Integer pagesize,
			List listdata,Integer prepage, Integer nextpage)
	{
		super();
		
		this.totalrow = totalrow;
		
		this.totalpage = totalpage;
		
		this.pageno =pageno;
		
		this.pagesize = pagesize;
		
		this.listdata = listdata;	
		
		this.prepage = prepage;
		
		this.nextpage = nextpage;
		
	}
	
	
}
