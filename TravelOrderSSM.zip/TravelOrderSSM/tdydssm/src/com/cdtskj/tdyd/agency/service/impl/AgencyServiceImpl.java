package com.cdtskj.tdyd.agency.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.tdyd.agency.dao.IAgencyDAO;
import com.cdtskj.tdyd.agency.dao.impl.AgencyDAOImpl;
import com.cdtskj.tdyd.agency.service.IAgencyService;

import com.cdtskj.util.Pagination;



public class AgencyServiceImpl implements IAgencyService 
{
	
	private IAgencyDAO dao;
	
	

	public IAgencyDAO getDao() 
	{
		return dao;
	}

	public void setDao(IAgencyDAO dao) 
	{
		this.dao = dao;
	}
	
	

	public void addAgency(LyAgency agency)
	{
		try
		{
		 		 
		 this.dao.add(agency);	 
		  
		 
		}
		catch(Exception ex)
		{
			System.out.println("AgencyServiceImpl.addAgency() Script error: " + ex.toString());
		}
	}
	
	
	
	public void updateAgency(LyAgency agency)  
	{
		
		
		try
		{
			this.dao.update(agency);
		}
		catch(Exception ex)
		{
			System.out.println("AgencyServiceImpl.updateAgency() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteAgency(LyAgency agency)
	{
		try
		{ 
			 this.dao.delete(agency.getAgencyid());		 			  
		}
		catch(Exception ex)
		{
			System.out.println("AgencyServiceImpl.deleteAgency() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyAgency queryAgencyById(Integer id)
	{		  
		 
		 LyAgency agency=this.dao.get(LyAgency.class, id);		 
		  
		 
		 return agency;
	}
	
	
	
	public List<LyAgency> querySuitableAgencys()
	{		 
		 
		 List<LyAgency> agencys=this.dao.getAll(LyAgency.class) ;
		  
		 
		 return agencys;
	}
	
	
	
	public Pagination queryPaginationAgency(LyAgency agency, Integer pageno, Integer pagesize)
	{
		 
		
		Pagination mypagi = null;
		
		try
		{
			Map param = new HashMap();						
			
			param.put("code",agency.getCode());
			
			param.put("name",agency.getName());						
			
			mypagi = this.dao.find(param, pageno, pagesize);
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.toString());
		}	
		 
		
		return mypagi;
		
	}
	
	
}
