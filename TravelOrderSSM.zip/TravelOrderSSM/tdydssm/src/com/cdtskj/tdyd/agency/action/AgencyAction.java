package com.cdtskj.tdyd.agency.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

 
import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.LyGuide;
import com.cdtskj.querypara.AgencyParam;
import com.cdtskj.querypara.GuideParam;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.tdyd.agency.service.impl.AgencyServiceImpl;
import com.cdtskj.util.PageParam;
import com.cdtskj.util.Pagination;
 
 

@RequestMapping(value="/agency")

@Controller

public class AgencyAction 
{
	
	@Resource
	
	private IAgencyService agencyService;
	
		
	
	
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	
	public String save(LyAgency agency)
	{
		
		
		if (agency.getAgencyid()!=null)
		{
			agencyService.updateAgency(agency);
		}
		else
		{
			agencyService.addAgency(agency);
		}
		
		return "forward:list.action";
	}
	
	
	
	
	@RequestMapping(value="/delete")
	
	public String delete(Integer agencyid)
	{
		try
		{	
			LyAgency agency = agencyService.queryAgencyById(agencyid);;
			
			agencyService.deleteAgency(agency);	
			
		}
		catch(Exception ex )
		{
			System.out.println("AgencyAction.delete() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";
	}
	
	
	
	
	
	
	@RequestMapping(value="/list")
	
	public String list(Map<String,Object> map)
	{
		AgencyParam agencyParam = new AgencyParam();
		
		LyAgency agency= new LyAgency();
		
		PageParam  pageParam = new PageParam();
		
		
		agencyParam.setAgency(agency);
		
		agencyParam.setPageParam(pageParam);
		
		
		map.put("agencyParam", agencyParam);
			 
		
		return "/html/tdyd/agency/agencylist";
	}
	
	
	
	@RequestMapping(value="/addui")
	
	public String addui(Map<String,Object> map)
	{
		LyAgency agency=new LyAgency();
		
		map.put("agency", agency);
		
		return "/html/tdyd/agency/agencydata";
	}
	
	
	
	
	@RequestMapping(value="/updateui")
	
	public String updateui(Integer agencyid,Map<String,Object> map)
	{				
		LyAgency agency = agencyService.queryAgencyById(agencyid);		
		
		map.put("agency", agency);
		
		return "/html/tdyd/agency/agencydata";
	}
	
	
	 
	
	
	@RequestMapping(value="/query", method={RequestMethod.POST,RequestMethod.GET})
	
	public String query(AgencyParam agencyParam, Map<String,Object> map)
	{
		
		//1.Dim variable
		
		List<LyAgency> list = null;
		
		Pagination mypagi = null;
		
		LyAgency agency = null; 
		
		PageParam pageParam= null;  
		
		Integer pageno = 0;
		
		Integer pageSize = 0;
		 		 
		
		
		try
		{
			
			//2.Get param
			
			 
			
			agency = agencyParam.getAgency();
			
			pageParam = agencyParam.getPageParam();
			
			
			if(pageParam != null )
			{
				
				pageno = pageParam.getPageno();
				
				//pageSize = pageParam.getPagesize();
			
			}
			
			pageSize =3;
			
			
			//3.Getdata
			
			 mypagi = agencyService.queryPaginationAgency(agency, pageno, pageSize);
			
		     map.put("mypagi",mypagi);
		     
		     map.put("agency", agency);
		     				
		}
		catch(Exception ex)
		{
			System.out.println("AgencyAction.query() Script error: " + ex.toString());			
		}
		
		return "/html/tdyd/agency/agencylist";
		
	}

	
}
