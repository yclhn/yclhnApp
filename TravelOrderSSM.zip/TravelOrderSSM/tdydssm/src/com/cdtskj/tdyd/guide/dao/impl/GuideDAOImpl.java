package com.cdtskj.tdyd.guide.dao.impl;

import com.cdtskj.pojo.LyGuide;
import com.cdtskj.tdyd.guide.dao.IGuideDAO;
import com.cdtskj.xt.base.BaseDAOImpl;

public class GuideDAOImpl  extends BaseDAOImpl<LyGuide> implements IGuideDAO 
{

}
