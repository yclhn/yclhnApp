package com.cdtskj.tdyd.guide.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cdtskj.pojo.LyGuide;
import com.cdtskj.tdyd.agency.dao.IAgencyDAO;
import com.cdtskj.tdyd.guide.dao.IGuideDAO;
import com.cdtskj.tdyd.guide.service.IGuideService;
import com.cdtskj.util.Pagination;

public class GuideServiceImpl implements IGuideService
{
	
	private IGuideDAO dao;
	
	private IAgencyDAO agencyDao;
	

	public IGuideDAO getDao() 
	{
		return dao;
	}

	public void setDao(IGuideDAO dao) 
	{
		this.dao = dao;
	}
	
	

	public IAgencyDAO getAgencyDao() 
	{
		return agencyDao;
	}

	public void setAgencyDao(IAgencyDAO agencyDao) 
	{
		this.agencyDao = agencyDao;
	}

	
	
	
	
	public void addGuide(LyGuide guide)
	{
		try
		{
			 this.dao.add(guide);		 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("GuideServiceImpl.addGuide() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void updateGuide(LyGuide guide)  
	{	
		
		try
		{ 
			this.dao.update(guide);			 			
		}
		catch(Exception ex)
		{
			System.out.println("GuideServiceImpl.updateGuide() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteGuide(LyGuide guide)
	{
		try
		{ 
			 this.dao.delete(guide.getGuideid());			 			  
		}
		catch(Exception ex)
		{
			System.out.println("GuideServiceImpl.deleteGuide() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyGuide queryGuideById(Integer id)
	{
		 LyGuide guide=this.dao.get(LyGuide.class, id);	 		  
		 
		 return guide;
	}
	
	
	
	public List<LyGuide> querySuitableGuides()
	{
		 List<LyGuide> guides=this.dao.getAll(LyGuide.class);
		 		 
		 return guides;
	}
	
	
	
	public Pagination queryPaginationGuide(LyGuide guide, Integer pageno, Integer pagesize)
	{		 
		
		Pagination mypagi = null;
		
		try
		{	
			
			Map param =new HashMap();			
			
			param.put("name", guide.getName());
			
			param.put("sex", guide.getSex());
			 
			
			mypagi = this.dao.find(param, pageno, pagesize);
			
		}
		catch(Exception ex)
		{
			System.out.println("GuideServiceImpl.queryPaginationGuide() Script error: " + ex.toString());
		}
				
		return mypagi;
		
	}

}
