package com.cdtskj.tdyd.guide.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.LyGuide;
import com.cdtskj.querypara.AgencyParam;
import com.cdtskj.querypara.GuideParam;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.tdyd.guide.service.IGuideService;
import com.cdtskj.util.PageParam;
import com.cdtskj.util.Pagination;
 

@RequestMapping(value="/guide")

@Controller

public class GuideAction  
{

	@Resource
	
	private IGuideService guideService;
	
	
	@Resource
	
	private IAgencyService agencyService; 
	
	 
	
	
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	
	public String save(LyGuide guide)
	{
		if (guide.getGuideid()!=null)
		{
			guideService.updateGuide(guide);
		}
		else
		{
			guideService.addGuide(guide);
		}
		
		return "forward:list.action";
	}
	
	
	
	@RequestMapping(value="/delete")
	
	public String delete(Integer guideid)
	{
		try
		{
			if(guideid!=null)
			{				
				LyGuide guide = guideService.queryGuideById(guideid);
				
				guideService.deleteGuide(guide);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("GuideAction.delete() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";
		
	}
	
	
	
	
	@RequestMapping(value="/list")
	
	public String list(Map<String,Object> map)
	{
		GuideParam guideParam = new GuideParam();
		
		LyGuide guide= new LyGuide();
		
		PageParam  pageParam = new PageParam();
		
		
		guideParam.setGuide(guide); 
		
		guideParam.setPageParam(pageParam);
		
		
		map.put("guideParam", guideParam);
		
		
		Map<String,String> genders = new HashMap<String,String>();
		
		genders.put("", "") ;
		
		genders.put("M", "Male") ;
		
		genders.put("F", "Female") ;
		
		
		map.put("genders", genders);
			 
		
		return "/html/tdyd/guide/guidelist";
	}
	
	
	
	@RequestMapping(value="/addui")
	
	public String addui(Map<String,Object> map)
	{
		LyGuide guide=new LyGuide();
		
		map.put("guide", guide);
		
		
		List<LyAgency> agencys = agencyService.querySuitableAgencys();
		
		map.put("agencys", agencys);
		
				
		return "/html/tdyd/guide/guidedata";
		
	}

	
	
	@RequestMapping(value="/updateui")
	
	public String updateui(Integer guideid,Map<String,Object> map)
	{
		
		LyGuide guide=guideService.queryGuideById(guideid);
		
		map.put("guide", guide);
		
		
		List<LyAgency> agencys = agencyService.querySuitableAgencys();
		
		map.put("agencys", agencys);
				
		return "/html/tdyd/guide/guidedata";
				 
	}

	
	
	 
	@RequestMapping(value="/query", method={RequestMethod.POST,RequestMethod.GET})
	
	public String query(GuideParam guideParam,Map<String,Object> map)
	{
		
		//1.Dim variable
		
		List<LyGuide> list = null;
		
		Pagination mypagi = null;
		
		LyGuide guide = null; 
		
		PageParam pageParam= null;  
		
		Integer pageno = 0;
		
		Integer pageSize = 0;
		 		 
		
		
		try
		{
			
			//2.Get param			
			 
			
			guide = guideParam.getGuide();
			
			pageParam = guideParam.getPageParam();
			
			
			if(pageParam != null )
			{
				
				pageno = pageParam.getPageno();
				
				//pageSize = pageParam.getPagesize();
			
			}
			
			pageSize =3;
			
			
			//3.Getdata
			
			 mypagi = guideService.queryPaginationGuide(guide, pageno, pageSize);
			
		     map.put("mypagi",mypagi);		
		     
		     
		    Map<String,String> genders = new HashMap<String,String>();
				
			genders.put("", "") ;
			
			genders.put("M", "Male") ;
			
			genders.put("F", "Female") ;
			
			
			map.put("genders", genders);
			
			
			map.put("guide", guide);
		      
				
		}
		catch(Exception ex)
		{
			System.out.println("GuideAction.query() Script error: " + ex.toString());			
		}
		
		return "/html/tdyd/guide/guidelist";
		
	} 

	
}
