package com.cdtskj.tdyd.guide.service;

import java.util.List;

import com.cdtskj.pojo.LyGuide;
import com.cdtskj.util.Pagination;

public interface IGuideService 
{
	
	public void addGuide(LyGuide guide);
	
	public void updateGuide(LyGuide guide);
	
	public void deleteGuide(LyGuide guide);
	
	
	
	public LyGuide queryGuideById(Integer id);
	
	public List<LyGuide> querySuitableGuides();
	
	public Pagination queryPaginationGuide(LyGuide guide, Integer page, Integer rows);
	
}
