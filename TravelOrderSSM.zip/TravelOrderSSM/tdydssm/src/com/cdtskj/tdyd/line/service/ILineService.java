package com.cdtskj.tdyd.line.service;

import java.util.List;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.util.Pagination;

public interface ILineService 
{
	
	public void addLine(LyLine Line);
	
	public void updateLine(LyLine Line);
	
	public void deleteLine(LyLine Line);
	
	
	
	public LyLine queryLineById(Integer id);
	
	public List<LyLine> querySuitableLines();
	
	public Pagination queryPaginationLine(LyLine Line, Integer page, Integer rows);
	
	
}
