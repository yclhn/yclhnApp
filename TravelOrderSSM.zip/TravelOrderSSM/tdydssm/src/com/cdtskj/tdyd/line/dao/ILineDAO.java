package com.cdtskj.tdyd.line.dao;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.xt.base.IBaseDAO;

public interface ILineDAO extends IBaseDAO<LyLine>
{

}
