package com.cdtskj.tdyd.line.dao.impl;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.tdyd.line.dao.ILineDAO;
import com.cdtskj.xt.base.BaseDAOImpl;

public class LineDAOImpl extends BaseDAOImpl<LyLine> implements ILineDAO 
{

}
