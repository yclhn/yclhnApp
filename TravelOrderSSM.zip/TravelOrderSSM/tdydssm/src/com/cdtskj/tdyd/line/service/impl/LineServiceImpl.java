package com.cdtskj.tdyd.line.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.tdyd.line.dao.ILineDAO;
import com.cdtskj.tdyd.line.dao.impl.LineDAOImpl;
import com.cdtskj.tdyd.line.service.ILineService;

import com.cdtskj.util.Pagination;



public class LineServiceImpl implements ILineService
{
	
	private ILineDAO dao;
	
	
	public ILineDAO getDao() 
	{
		return dao;
	}


	public void setDao(ILineDAO dao) 
	{
		this.dao = dao;
	}



	public void addLine(LyLine Line)
	{
		try
		{
			 this.dao.add(Line);		 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("LineServiceImpl.addLine() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void updateLine(LyLine line)  
	{	
		
		try
		{ 
			this.dao.update(line); 			 			
		}
		catch(Exception ex)
		{
			System.out.println("LineServiceImpl.updateLine() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteLine(LyLine line)
	{
		try
		{ 
			 this.dao.delete(line.getLineid());			 			  
		}
		catch(Exception ex)
		{
			System.out.println("LineServiceImpl.deleteLine() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyLine queryLineById(Integer id)
	{
		 LyLine line=this.dao.get(LyLine.class, id);	 		  
		 
		 return line;
	}
	
	
	
	public List<LyLine> querySuitableLines()
	{
		 List<LyLine> lines=this.dao.getAll(LyLine.class);
		 		 
		 return lines;
	}
	
	
	
	public Pagination queryPaginationLine(LyLine line, Integer page, Integer rows)
	{		 
		
		Pagination mypagi = null;
		
		try
		{
			Map param = new HashMap();						
			
			param.put("code",line.getCode());
			
			param.put("name",line.getName());	
			 			
			mypagi = this.dao.find(param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println("LineServiceImpl.queryPaginationLine() Script error: " + ex.toString());
		}
				
		return mypagi;
		
	}
	

}
