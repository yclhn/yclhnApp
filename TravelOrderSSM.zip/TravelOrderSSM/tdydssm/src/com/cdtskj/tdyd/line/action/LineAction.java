package com.cdtskj.tdyd.line.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.querypara.LineParam;
import com.cdtskj.tdyd.line.service.ILineService;
import com.cdtskj.tdyd.line.service.impl.LineServiceImpl;
import com.cdtskj.util.PageParam;
import com.cdtskj.util.Pagination;
 

@RequestMapping(value="/line")

@Controller

public class LineAction  
{
	
	@Resource
	
	private ILineService lineService;
	
		
	
	
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	
	public String save(LyLine line)
	{
		
		
		if (line.getLineid()!=null)
		{
			lineService.updateLine(line);
		}
		else
		{
			lineService.addLine(line);
		}
		
		return "forward:list.action";
	}
	
	
	
	
	@RequestMapping(value="/delete")
	
	public String delete(Integer lineid)
	{
		try
		{	
			LyLine line = lineService.queryLineById(lineid);;
			
			lineService.deleteLine(line);	
			
		}
		catch(Exception ex )
		{
			System.out.println("LineAction.delete() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";
		
	}
	
	
	
	
	
	
	@RequestMapping(value="/list")
	
	public String list(Map<String,Object> map)
	{
		LineParam lineParam = new LineParam();
		
		LyLine line= new LyLine();
		
		PageParam  pageParam = new PageParam();
		
		
		lineParam.setLine(line);
		
		lineParam.setPageParam(pageParam);
		
		
		map.put("lineParam", lineParam);
			 
		
		return "/html/tdyd/line/linelist";
	}
	
	
	
	@RequestMapping(value="/addui")
	
	public String addui(Map<String,Object> map)
	{
		LyLine line=new LyLine();
		
		map.put("line", line);
		
		return "/html/tdyd/line/linedata";
	}
	
	
	
	
	@RequestMapping(value="/updateui")
	
	public String updateui(Integer lineid,Map<String,Object> map)
	{				
		LyLine line = lineService.queryLineById(lineid);		
		
		map.put("line", line);
		
		return "/html/tdyd/line/linedata";
	}
	
	
	 
	
	
	@RequestMapping(value="/query", method={RequestMethod.POST,RequestMethod.GET})
	
	public String query(LineParam lineParam,Map<String,Object> map)
	{
		
		//1.Dim variable
		
		List<LyLine> list = null;
		
		Pagination mypagi = null;
		
		LyLine line = null; 
		
		PageParam pageParam= null;  
		
		Integer pageno = 0;
		
		Integer pageSize = 0;
		 		 
		
		
		try
		{
			
			//2.Get param
			
			 
			
			line = lineParam.getLine();
			
			pageParam = lineParam.getPageParam();
			
			
			if(pageParam != null )
			{
				
				pageno = pageParam.getPageno();
				
				//pageSize = pageParam.getPagesize();
			
			}
			
			pageSize =3;
			
			
			//3.Getdata
			
			 mypagi = lineService.queryPaginationLine(line, pageno, pageSize);
			
		     map.put("mypagi", mypagi);
		     
		     map.put("line", line);
		     				
		}
		catch(Exception ex)
		{
			System.out.println("LineAction.query() Script error: " + ex.toString());			
		}
		
		return "/html/tdyd/line/linelist";
		
	}

}
