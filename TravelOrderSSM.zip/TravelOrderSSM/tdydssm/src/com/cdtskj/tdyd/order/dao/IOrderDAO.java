package com.cdtskj.tdyd.order.dao;

import com.cdtskj.pojo.LyOrder;
import com.cdtskj.xt.base.IBaseDAO;

public interface IOrderDAO extends IBaseDAO<LyOrder>
{
	
	
}
