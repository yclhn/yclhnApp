package com.cdtskj.tdyd.order.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.LyGuide;
import com.cdtskj.pojo.LyLine;
import com.cdtskj.pojo.LyOrder;
import com.cdtskj.querypara.OrderParam;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.tdyd.guide.service.IGuideService;
import com.cdtskj.tdyd.line.service.ILineService;
import com.cdtskj.tdyd.order.service.IOrderService;
import com.cdtskj.util.PageParam;
import com.cdtskj.util.Pagination;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
 


@RequestMapping(value="/order")

@Controller

public class OrderAction  
{
	
	
	@Resource
	
	private IOrderService orderService;
	
	
	@Resource
	
	private IAgencyService agencyService;
	
	
	@Resource
	
	private ILineService lineService;
	
	
	@Resource
	
	private IGuideService guideService;
	
		
	
	@InitBinder    
	
	public void initBinder(WebDataBinder binder) 
	{    
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");    
	        
	        dateFormat.setLenient(false);    
	        
	        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));    
	}  
	
	
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	
	public String save(LyOrder order)
	{
		
		
		if (order.getOrderid()!=null)
		{
			orderService.updateOrder(order);
		}
		else
		{
			orderService.addOrder(order);
		}
		
		return "forward:list.action";
	}
	
	
	
	
	@RequestMapping(value="/delete")
	
	public String delete(Integer orderid)
	{
		try
		{	
			LyOrder order = new LyOrder(); 

			order.setOrderid(orderid);
			
			orderService.deleteOrder(order);	
			
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.delete() Script error : " + ex.toString());			
		}
		
		return "forward:list.action";
	}
	
	
	
	
	
	
	@RequestMapping(value="/list")
	
	public String list(Map<String,Object> map)
	{
		OrderParam orderParam = new OrderParam();
		
		LyOrder order= new LyOrder();
		
		PageParam  pageParam = new PageParam();
		
		
		orderParam.setOrder(order);
		
		orderParam.setPageParam(pageParam);
		
		
		map.put("orderParam", orderParam);
			 
		
		return "/html/tdyd/order/orderlist";
	}
	
	
	
	@RequestMapping(value="/addui")
	
	public String addui(Map<String,Object> map)
	{
		LyOrder order=new LyOrder();
		
		map.put("order", order);
		
		List<LyAgency> agencys = agencyService.querySuitableAgencys();
		
		List<LyGuide>  guides = guideService.querySuitableGuides();
		
		List<LyLine>   lines = lineService.querySuitableLines();
		
		map.put("agencys", agencys);
		
		map.put("guides", guides);
		
		map.put("lines", lines);
		
		
		return "/html/tdyd/order/orderdata";
	}
	
	
	
	
	@RequestMapping(value="/updateui")
	
	public String updateui(Integer orderid, Map<String,Object> map)
	{				
		LyOrder order = orderService.queryOrderById(orderid);		
		
		map.put("order", order);
		
		List<LyAgency> agencys = agencyService.querySuitableAgencys();
		
		List<LyGuide>  guides = guideService.querySuitableGuides();
		
		List<LyLine>   lines = lineService.querySuitableLines();
		
		map.put("agencys", agencys);
		
		map.put("guides", guides);
		
		map.put("lines", lines);
		
		return "/html/tdyd/order/orderdata";
	}
	
	
	 
	
	
	@RequestMapping(value="/query", method={RequestMethod.POST,RequestMethod.GET})
	
	public String query(OrderParam orderParam, Map<String,Object> map)
	{
		
		//1.Dim variable
		
		List<LyOrder> list = null;
		
		Pagination mypagi = null;
		
		LyOrder order = null; 
		
		PageParam pageParam= null;  
		
		Integer pageno = 0;
		
		Integer pageSize = 0;
		 		 
		
		
		try
		{
			
			//2.Get param					 
			
			order = orderParam.getOrder();
			
			pageParam = orderParam.getPageParam();
			
			
			if(pageParam != null )
			{
				
				pageno = pageParam.getPageno();
				
				//pageSize = pageParam.getPagesize();
			
			}
			
			pageSize =3;
			
			
			//3.Getdata
			
			 mypagi = orderService.queryPaginationOrder(order, pageno, pageSize);
			
		     map.put("mypagi",mypagi);
		     
		     map.put("order", order);
		     				
		}
		catch(Exception ex)
		{
			System.out.println("OrderAction.query() Script error: " + ex.toString());			
		}
		
		return "/html/tdyd/order/orderlist";
		
	}
	
	
		 
	
	
	  
	
	@RequestMapping(value="/applyOrder")
	
	public void applyOrder(LyOrder order)
	{
		
		try
		{
			 order.setZt("apply");
			 
			 this.orderService.applyOrder(order);
			 
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.applyOrder() Script error : " + ex.toString());			
		}
		
	}
	
	
	
	
	@RequestMapping(value="/upload")
	
	public String upload(Integer orderid, Map<String,Object> map)
	{
		LyOrder order = orderService.queryOrderById(orderid);
		
		map.put("order", order);
		
		return "/html/tdyd/order/orderupload";
	}
	
	
	
	
	@RequestMapping(value="/uploadFile")
	
	public String uploadFile(LyOrder order, MultipartFile upload)
	{
		String strFile="",strFilename="",strExt="",strOrgFileName="";
		String strPath="D:/UplodJavaData";
		
		try
		{
			if(upload != null)
			{
				
				//1.Get dest filename
				
				SimpleDateFormat myfmt =new SimpleDateFormat("yyyyMMddHHmmssSSS");
				
				Date mydt = new Date();
				
				strFilename = myfmt.format(mydt);
				
				strOrgFileName = upload.getOriginalFilename();
							
				strExt = strOrgFileName.substring(strOrgFileName.lastIndexOf("."),strOrgFileName.length()) ;
				
				strFilename = strFilename + strExt;
								
						    
				//2.Creat dest file
				
				strFile = strPath+ "/" + strFilename;
								
				File destFile = new File(strFile);								 
								 
				upload.transferTo( destFile);
				
				
				//3.Set order filename
				
				order.setFilename(strOrgFileName);
				
				order.setRealfilename(strFilename);				
				
				this.orderService.updateOrderFilename(order);
				
				return "forward:list.action";			
			}
			else
			{
				return "forward:upload.action";
			}
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.uploadFile() Script error : " + ex.toString());			
		}		
		
		return "forward:list.action";
		
	}
	
	
	@RequestMapping(value="/examinePass")
	
	public String examinePass(LyOrder order)
	{
		try
		{
			this.orderService.examinePass(order);
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.examinePass() Script error : " + ex.toString());			
		}
		
 		return "forward:list.action";
	}
	
	
	
	
	@RequestMapping(value="/exam")
	
	public String exam(Integer orderid, Map<String,Object> map)
	{
		try
		{
			LyOrder order = this.orderService.queryOrderById(orderid);
			
			map.put("order", order);
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.examinePass() Script error : " + ex.toString());			
		}
		
		return "/html/tdyd/order/orderexam";
	}
	
	
	
	@RequestMapping(value="/downloadFile")
	
	public ResponseEntity<byte[]> downloadFile(Integer orderid)	
	{
		
		//1.Dim variable		
		String strFilename="",strFile="",strOrgFileName="";		
		String strPath="";
		ResponseEntity<byte[]> res = null;
		
		try
		{
			//2.Get file
			
			strPath = "D:/UplodJavaData";
			
			LyOrder tempOrder  = this.orderService.queryOrderById(orderid);
			
			strFilename = tempOrder.getRealfilename();
			
			strOrgFileName=tempOrder.getFilename();
			
			strFile = strPath + "/" + strFilename;
			
			File myfile = new File(strFile);
			
			
			//3.Download file
			
			HttpHeaders headers = new HttpHeaders();
			
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			
			headers.setContentDispositionFormData("attachment", strOrgFileName);
			
			res =new ResponseEntity<byte[]>(			 			
			 FileUtils.readFileToByteArray(myfile), headers, HttpStatus.CREATED); 
			  
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.downloadFile() Script error : " + ex.toString());			
		}
		
		return res;
	}	
	
}
