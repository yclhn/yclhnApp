package com.cdtskj.tdyd.order.dao.impl;

import com.cdtskj.pojo.LyOrder;
import com.cdtskj.tdyd.order.dao.IOrderDAO;
import com.cdtskj.xt.base.BaseDAOImpl;

public class OrderDAOImpl extends BaseDAOImpl<LyOrder> implements IOrderDAO 
{

}
