/*
SQLyog Enterprise v12.08 (64 bit)
MySQL - 5.6.24-log : Database - tdyd
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`tdyd` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `tdyd`;

/*Table structure for table `ly_agency` */

DROP TABLE IF EXISTS `ly_agency`;

CREATE TABLE `ly_agency` (
  `agencyid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `code` varchar(30) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`agencyid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

/*Data for the table `ly_agency` */

insert  into `ly_agency`(`agencyid`,`name`,`code`,`phone`,`email`,`remark`) values (1,'GuangZhou WuYang Travel Company LTD','4401','020-83162179','wytravel@163.com','OverSea travel'),(2,'ShenZhen DaPeng Travel Company','4402','0755-23018126','dptravel@263.com','All Travel Business'),(3,'ZuHai YuZhu TravelL Company LTD','4403','0756-81303462','yztravel@126.com','Travel Business for HK and Macau'),(4,'DongGuan GuanYi Travel Company LTD','4419','0769-23108106','gytravel@163.com','Travel Business for GUANGDONG Province'),(5,'ZhongShan XiaoLan Travel Company','4420','0760-82103125','xltravel@263.com','Travel Business for Macau and CHINA'),(6,'ShanTou NanAo Travel Company LTD','440401','0754-27836126','natravel@163.com','GuangDong Province Travel'),(8,'FoShan ChanCheng Travel Company','440501','0757-67218913','cctravel@163.com','China Travel  '),(9,'HeYuan DongJiang Travel Company LTD','4413','0753-81287982','djtravel@163.com','US,HK and Macau Travel'),(11,'JiangMen WuYi Travel Company LTD','4416','0750-81236825','wytravel@126.com','China Travel , US'),(13,'ZhanJiang XiaShan Travel Company LTD','441801','0768-28010036','xstravel@126.net','HK.MAcau,US,Europe Travel'),(14,'Shao Guan Dan Xia Travel Company LTD','441201','0751-83102172','dxtravel@163.com','Guang Dong Province,HK Travel'),(15,'Qing Yuan Ying De Travel Company','441301','0761-27189362','ydtravel@126.com','HK,Macau Travel'),(17,'ZaoQing DingHu Travel Company','441701','0768-26103251','dhtravel@163.com','HK.MAcau,US,Europe Travel');

/*Table structure for table `ly_guide` */

DROP TABLE IF EXISTS `ly_guide`;

CREATE TABLE `ly_guide` (
  `guideid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `agencyid` int(11) DEFAULT NULL,
  `qqnum` varchar(20) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`guideid`),
  KEY `FK_GUIDE_AGENCYID` (`agencyid`),
  CONSTRAINT `FK_GUIDE_AGENCYID` FOREIGN KEY (`agencyid`) REFERENCES `ly_agency` (`agencyid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `ly_guide` */

insert  into `ly_guide`(`guideid`,`name`,`phone`,`email`,`sex`,`agencyid`,`qqnum`,`remark`) values (1,'Liu Ruo Ying','13721013209','ryliu@126.com','F',1,'60018312','Guide 5 star'),(2,'Liu De Hua','13538062301','dhliu@126.com','M',3,'39186289','Guide 3 star'),(3,'Zhang Xue You','15123018732','xyzhang@163.com','M',5,'78204563','Guide 5 star'),(4,'Guo Fu Cheng','13690217835','fcguo@263.com','M',4,'31278932','Guide 2 star'),(5,'Ye Qing Wen','13278934628','qwye@163.com','F',2,'53097821','Guide 5 star'),(6,'Zheng Zhong Ji','13027631238','zjz@263.com','M',2,'80231783','Guide 5 star'),(7,'Hui Ying Hong','13933012862','yhh@126.com','F',2,'62017852','Guide 3 star'),(8,'Jia Jing Wen','13630897325','jjw@263.com','F',1,'21789236','Guide 5 star'),(9,'Zhang Tian Xiang','13928213695','ztx@263.com','M',5,'30287651','5 Star'),(10,'Hu Rong Ping','13620163875','hrp@126.com','F',11,'26813572','3 star'),(12,'Bao Xin Ye','13169812356','bxy@163.com','M',2,'83279825','star 5'),(13,'N-5','P-5','E-5','M',1,'Q-5','T-5');

/*Table structure for table `ly_line` */

DROP TABLE IF EXISTS `ly_line`;

CREATE TABLE `ly_line` (
  `lineid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `fromplace` varchar(200) DEFAULT NULL,
  `toplace` varchar(200) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`lineid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

/*Data for the table `ly_line` */

insert  into `ly_line`(`lineid`,`name`,`code`,`fromplace`,`toplace`,`price`,`remark`) values (1,'USA EAST','1001','GuangZhou','NewYork',28000,'OverSea-USA-1'),(2,'USA WEST','1002','ShenZhen','LA',23000,'OverSea-USA-2'),(3,'USA SOUTH','1003','ShenZhen','OSTIN',15000,'OverSea-USA-3'),(4,'USA NORTH','1004','GuangZhou','Chicago',18000,'OverSea-USA-4'),(5,'CANADA','1005','GuangZhou','Tolento',18000,'OverSea-USA-5'),(6,'British','1006','GuangZhou','London',24000,'OverSea-Europe-6'),(7,'France','1007','HongKong','Paris',24000,'OverSea-Europe-7'),(8,'Germany','1008','HongKong','BoLin',24000,'OverSea-Europe-8'),(12,'CHINA SOUTH','2004','ShenZhen','GuiLin',2800,'Mainland-4'),(13,'CHINA CENTER','2005','GuangZhou','WuHan',1800,'Mainland-5'),(14,'CHINA Complex HuNan','3001','GuangZhou','ChangSha',2200,'HN-1'),(15,'CHINA Complex JiangXi','3002','ShenZhen','NanChang',2400,'JX-1'),(16,'CHINA EAST','2001','HK','ShangHai',3000,'Mainland-1'),(17,'CHINA NORTH','2002','GuangZhou','BeiJing',5000,'Mainland-2'),(18,'CHINA WEST','2003','ShenZhen','ChengDu',3500,'Mainland-3'),(19,'CHINA Complex JiangSu','3006','GuangZhou','NanJing',2600,'JS-1'),(20,'CHINA Complex YunNan','3007','ShenZhen','KunMing',2400,'YN-1'),(22,'CHINA Complex HuBei','3008','HongKong','WuHan',2200,'HB-1');

/*Table structure for table `ly_order` */

DROP TABLE IF EXISTS `ly_order`;

CREATE TABLE `ly_order` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `countnum` int(11) DEFAULT NULL,
  `timeuse` int(11) DEFAULT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `zt` varchar(10) DEFAULT NULL,
  `guideid` int(11) DEFAULT NULL,
  `lineid` int(11) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `agencyid` int(11) DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `realfilename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`orderid`),
  KEY `FK_ORDER_AGENCYID` (`agencyid`),
  KEY `FK_ORDER_GUIDEID` (`guideid`),
  KEY `FK_ORDER_LINEID` (`lineid`),
  CONSTRAINT `FK_ORDER_AGENCYID` FOREIGN KEY (`agencyid`) REFERENCES `ly_agency` (`agencyid`) ON DELETE CASCADE,
  CONSTRAINT `FK_ORDER_GUIDEID` FOREIGN KEY (`guideid`) REFERENCES `ly_guide` (`guideid`) ON DELETE CASCADE,
  CONSTRAINT `FK_ORDER_LINEID` FOREIGN KEY (`lineid`) REFERENCES `ly_line` (`lineid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `ly_order` */

insert  into `ly_order`(`orderid`,`title`,`countnum`,`timeuse`,`startdate`,`enddate`,`zt`,`guideid`,`lineid`,`remark`,`agencyid`,`filename`,`realfilename`) values (1,'USA EAST Travel (NewYork DC Boston)',50,16,'2016-11-01','2016-11-16','pass',2,1,'Approved,Please booking ticket',3,'NYC.txt','20161101142631991.txt'),(2,'Europe London Travel (London Mancheste)',30,10,'2016-11-05','2016-11-15','pass',6,6,'Approved,Please contact with local agent',2,'London.xlsx','20161101142618381.xlsx'),(3,'Europe Paris Travel (Paris Masai Gala)',70,12,'2016-11-10','2016-11-22','pass',5,7,'OK',1,'ParisTravel.docx','20161101115522279.docx'),(4,'South Jiang Su Travel (NanJing,WuXi,SuZhou)',75,12,'2016-12-03','2016-12-15','pass',8,12,'OK',5,'JiangSuTravel.pdf','20161101115555299.pdf'),(5,'HuNan ZhangJiaJie Travel (ChangSha,YueYang,ZhangJiaJie)',90,12,'2016-12-11','2016-12-23','pass',3,12,'OK',9,'ZhangJiaJieTravel.docx','20161101115652270.docx'),(6,'ShanXia Travel',30,6,'2016-11-21','2016-11-26','pass',5,22,'OK',2,'ShanXiaTravel.xlsx','20161101124244046.xlsx'),(7,'BeiJing Travel (BeiJing,TianJing,TaiYuan)',90,10,'2016-11-09','2016-11-19',NULL,2,17,'70 percent',4,'BJtravel.txt','20161101124317350.txt'),(11,'YunNan Travel(KunMing,DaLi)',30,10,'2016-11-13','2016-11-23',NULL,9,20,'85 percent',1,'YunNan.xlsx','20161101125035525.xlsx'),(12,'NanChang Travel(NanChang,JiuJiang,JiAn)',30,8,'2016-12-05','2016-12-13','pass',8,12,'ok',4,NULL,NULL),(13,'ZheJiang Travel(HangZhou,NingBo,WenZhou)',60,9,'2016-12-01','2016-12-10','pass',5,16,'ok',2,NULL,NULL),(14,'FuJian Travel',50,8,'2016-12-05','2016-12-13',NULL,5,12,'90 percent',4,NULL,NULL);

/*Table structure for table `xt_log` */

DROP TABLE IF EXISTS `xt_log`;

CREATE TABLE `xt_log` (
  `logid` int(11) NOT NULL AUTO_INCREMENT,
  `describes` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `operator` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

/*Data for the table `xt_log` */

insert  into `xt_log`(`logid`,`describes`,`date`,`remark`,`operator`) values (1,'Logging System','2016-11-01 10:33:34','Write by Spring AOP test','ycl'),(2,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 10:37:43','Write by Spring AOP test','ycl'),(3,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 10:40:12','Write by Spring AOP test','ycl'),(4,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 10:45:56','Write by Spring AOP test','ycl'),(5,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 10:47:46','Write by Spring AOP test','ycl'),(6,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 10:53:08','Write by Spring AOP test','ycl'),(7,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 10:56:54','Write by Spring AOP test','ycl'),(8,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.updateGuide','2016-11-01 10:59:35','Write by Spring AOP test','ycl'),(9,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 11:00:30','Write by Spring AOP test','ycl'),(10,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 11:01:28','Write by Spring AOP test','ycl'),(11,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.deleteOrder','2016-11-01 11:02:06','Write by Spring AOP test','ycl'),(12,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.deleteOrder','2016-11-01 11:02:40','Write by Spring AOP test','ycl'),(13,'Logging System','2016-11-01 11:25:36','Write by Spring AOP test','ycl'),(14,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 11:26:29','Write by Spring AOP test','ycl'),(15,'Logging System','2016-11-01 11:44:32','Write by Spring AOP test','ycl'),(16,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 11:46:04','Write by Spring AOP test','ycl'),(17,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 11:47:25','Write by Spring AOP test','ycl'),(18,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 11:49:36','Write by Spring AOP test','ycl'),(19,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 11:51:07','Write by Spring AOP test','ycl'),(20,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 11:52:52','Write by Spring AOP test','ycl'),(21,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 11:55:26','Write by Spring AOP test','ycl'),(22,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 11:55:59','Write by Spring AOP test','ycl'),(23,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 11:56:56','Write by Spring AOP test','ycl'),(24,'Logging System','2016-11-01 12:27:06','Write by Spring AOP test','ycl'),(25,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.addGuide','2016-11-01 12:30:18','Write by Spring AOP test','ycl'),(26,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.updateGuide','2016-11-01 12:32:24','Write by Spring AOP test','ycl'),(27,'class com.cdtskj.tdyd.agency.service.impl.AgencyServiceImpl.updateAgency','2016-11-01 12:33:29','Write by Spring AOP test','ycl'),(28,'class com.cdtskj.tdyd.agency.service.impl.AgencyServiceImpl.updateAgency','2016-11-01 12:34:10','Write by Spring AOP test','ycl'),(29,'class com.cdtskj.tdyd.agency.service.impl.AgencyServiceImpl.updateAgency','2016-11-01 12:34:37','Write by Spring AOP test','ycl'),(30,'class com.cdtskj.tdyd.agency.service.impl.AgencyServiceImpl.updateAgency','2016-11-01 12:35:19','Write by Spring AOP test','ycl'),(31,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.addGuide','2016-11-01 12:36:51','Write by Spring AOP test','ycl'),(32,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.updateGuide','2016-11-01 12:38:19','Write by Spring AOP test','ycl'),(33,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.addGuide','2016-11-01 12:39:29','Write by Spring AOP test','ycl'),(34,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.addGuide','2016-11-01 12:40:15','Write by Spring AOP test','ycl'),(35,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.updateGuide','2016-11-01 12:41:25','Write by Spring AOP test','ycl'),(36,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.deleteGuide','2016-11-01 12:41:39','Write by Spring AOP test','ycl'),(37,'class com.cdtskj.tdyd.guide.service.impl.GuideServiceImpl.addGuide','2016-11-01 12:42:09','Write by Spring AOP test','ycl'),(38,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 12:42:51','Write by Spring AOP test','ycl'),(39,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 12:43:17','Write by Spring AOP test','ycl'),(40,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 12:44:12','Write by Spring AOP test','ycl'),(41,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 12:46:56','Write by Spring AOP test','ycl'),(42,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.deleteOrder','2016-11-01 12:47:22','Write by Spring AOP test','ycl'),(43,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 12:48:40','Write by Spring AOP test','ycl'),(44,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 12:49:06','Write by Spring AOP test','ycl'),(45,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 12:50:36','Write by Spring AOP test','ycl'),(46,'Logging System','2016-11-01 14:18:54','Write by Spring AOP test','ycl'),(47,'Logging System','2016-11-01 14:23:27','Write by Spring AOP test','ycl'),(48,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 14:25:56','Write by Spring AOP test','ycl'),(49,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 14:26:18','Write by Spring AOP test','ycl'),(50,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrderFilename','2016-11-01 14:26:32','Write by Spring AOP test','ycl'),(51,'Logging System','2016-11-01 16:20:27','Write by Spring AOP test','ycl'),(52,'Logging System','2016-11-01 16:42:43','Write by Spring AOP test','ycl'),(53,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 16:48:00','Write by Spring AOP test','ycl'),(54,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 16:49:42','Write by Spring AOP test','ycl'),(55,'Logging System','2016-11-01 17:17:03','Write by Spring AOP test','ycl'),(56,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:17:55','Write by Spring AOP test','ycl'),(57,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:19:48','Write by Spring AOP test','ycl'),(58,'Logging System','2016-11-01 17:23:05','Write by Spring AOP test','ycl'),(59,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:23:32','Write by Spring AOP test','ycl'),(60,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:25:00','Write by Spring AOP test','ycl'),(61,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:25:43','Write by Spring AOP test','ycl'),(62,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:26:26','Write by Spring AOP test','ycl'),(63,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:26:54','Write by Spring AOP test','ycl'),(64,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:27:31','Write by Spring AOP test','ycl'),(65,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:27:45','Write by Spring AOP test','ycl'),(66,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:28:01','Write by Spring AOP test','ycl'),(67,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:28:17','Write by Spring AOP test','ycl'),(68,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 17:29:35','Write by Spring AOP test','ycl'),(69,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:30:54','Write by Spring AOP test','ycl'),(70,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 17:31:42','Write by Spring AOP test','ycl'),(71,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 17:33:27','Write by Spring AOP test','ycl'),(72,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.examinePass','2016-11-01 17:34:37','Write by Spring AOP test','ycl'),(73,'Logging System','2016-11-01 17:51:31','Write by Spring AOP test','ycl'),(74,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.addOrder','2016-11-01 17:52:57','Write by Spring AOP test','ycl'),(75,'Logging System','2016-11-01 17:54:22','Write by Spring AOP test','admin'),(76,'class com.cdtskj.tdyd.order.service.impl.OrderServiceImpl.updateOrder','2016-11-01 17:57:00','Write by Spring AOP test','admin');

/*Table structure for table `xt_user` */

DROP TABLE IF EXISTS `xt_user`;

CREATE TABLE `xt_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `loginname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `zt` int(11) DEFAULT NULL,
  `agencyid` int(11) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `FK_USER_AGENCYID` (`agencyid`),
  CONSTRAINT `FK_USER_AGENCYID` FOREIGN KEY (`agencyid`) REFERENCES `ly_agency` (`agencyid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/*Data for the table `xt_user` */

insert  into `xt_user`(`userid`,`name`,`loginname`,`password`,`email`,`zt`,`agencyid`) values (1,'System Administrator','admin','123','tdydadm@163.com',1,4),(2,'YCL','ycl','123','ycl@163.com',1,4),(3,'Liu Xiao Hua','lxh','123','lxh@126.com',1,4),(4,'Hu Zheng Qing','hzq','123','hzq@163.com',1,1),(5,'Huang Guan Fu','hgf','123','hgf@263.com',1,2),(6,'Wang Cheng Li','wcl','123','wcl@163.com',1,3),(8,'Zhou Hai Jun','zhj','123','zhj@163.com',1,5),(9,'Liu De Kai','ldk','123','ldk@126.com',1,2),(11,'Jia JIng Wen','jjw','123','jjw@163.com',1,2),(12,'Guo Fu Cheng','gfc','123','gfc@126.com',1,5),(13,'Zhang Xue You','zxy','123','zxy',1,5),(14,'Xie Ting Feng','xtf','123','xtf@126.com',1,2),(15,'Chen Yi Xun','cyx','123','cyx@126.com',1,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
