import java.util.List;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.xt.base.BaseDAOImpl;
import com.cdtskj.xt.base.IBaseDAO;

public class test 
{
	
	public void main(String [] args)
	{
		IBaseDAO myfun = new BaseDAOImpl();
		
		List<LyAgency> list = myfun.find("from LyAgency");
		
		int intK=list.size();
	}

}
