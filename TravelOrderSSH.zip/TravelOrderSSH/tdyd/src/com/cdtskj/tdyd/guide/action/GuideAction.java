package com.cdtskj.tdyd.guide.action;

import java.util.List;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.LyGuide;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.tdyd.guide.service.IGuideService;
import com.cdtskj.util.Pagination;
import com.opensymphony.xwork2.ActionSupport;

public class GuideAction  extends ActionSupport
{

	private IGuideService guideService;
	
	private IAgencyService agencyService; 
	
	private List<LyAgency> listAgency;
	
	
	
	private Integer guideid;
	
	private String name;	

	private String sex;
	
	private List<LyGuide> list ;
	
	private LyGuide guide;
	
	
	private Integer pageno;
	
	private Integer totalpage;
	
	private Integer totalrow;
	
	private Integer pageSize;
	
	private Integer nextpage;
	
	private Integer prepage;
	
	
	
	 

	public List<LyAgency> getListAgency() 
	{
		return listAgency;
	}


	public void setListAgency(List<LyAgency> listAgency) 
	{
		this.listAgency = listAgency;
	}


	public IGuideService getGuideService() 
	{
		return guideService;
	}


	public void setGuideService(IGuideService guideService) 
	{
		this.guideService = guideService;
	}


	public Integer getGuideid() 
	{
		return guideid;
	}


	public void setGuideid(Integer guideid) 
	{
		this.guideid = guideid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) 
	{
		this.name = name;
	}


	public String getSex() 
	{
		return sex;
	}


	public void setSex(String sex) 
	{
		this.sex = sex;
	}


	public List<LyGuide> getList() 
	{
		return list;
	}


	public void setList(List<LyGuide> list) 
	{
		this.list = list;
	}


	public LyGuide getGuide() 
	{
		return guide;
	}


	public void setGuide(LyGuide guide) 
	{
		this.guide = guide;
	}


	public Integer getPageno() 
	{
		return pageno;
	}


	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}


	public Integer getTotalpage() 
	{
		return totalpage;
	}


	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}


	public Integer getTotalrow() 
	{
		return totalrow;
	}


	public void setTotalrow(Integer totalrow) 
	{
		this.totalrow = totalrow;
	}


	public Integer getNextpage() 
	{
		return nextpage;
	}


	public void setNextpage(Integer nextpage) 
	{
		this.nextpage = nextpage;
	}


	public Integer getPrepage() 
	{
		return prepage;
	}


	public void setPrepage(Integer prepage) 
	{
		this.prepage = prepage;
	}


	public IAgencyService getAgencyService() 
	{
		return agencyService;
	}


	public void setAgencyService(IAgencyService agencyService) 
	{
		this.agencyService = agencyService;
	}


	
	
	
	public String save()
	{
		if (guide.getGuideid()!=null)
		{
			guideService.updateGuide(guide);
		}
		else
		{
			guideService.addGuide(guide);
		}
		
		return "list";
	}
	
	
	
	public String delete()
	{
		try
		{
			if(guideid!=null)
			{				
				LyGuide tempGuide = new LyGuide();
				
				tempGuide.setGuideid(guideid);
				
				guideService.deleteGuide(tempGuide);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("GuideAction.delete() Script error : " + ex.toString());			
		}
		
		return "list";
		
	}
	
	
	
	public String edit()
	{
		try
		{
			guide = guideService.queryGuideById(guideid);	
			
			listAgency = agencyService.querySuitableAgencys();
		}
		catch(Exception ex )
		{
			System.out.println("GuideAction.edit() Script error : " + ex.toString());			
		}
		
		return "data";
		
	}
	
	
	public String add()
	{
		try
		{
			listAgency = agencyService.querySuitableAgencys();
		}
		catch(Exception ex )
		{
			System.out.println("GuideAction.add() Script error : " + ex.toString());			
		}
		
		return "data";
	}
	 
	
	
	public String query()
	{
		try
		{
			LyGuide tempGuide = new LyGuide();
			
			if(sex==null)
			{
				sex="";
			}
			
			tempGuide.setSex(sex);
			
			if(name==null)
			{
				name="";
			}
			
			tempGuide.setName(name);
			
			Pagination mypagi = guideService.queryPaginationGuide(tempGuide, pageno, pageSize);
			
			if(mypagi != null)
			{				
				list=(List<LyGuide>)mypagi.getRows();
				
				totalrow =Integer.parseInt( mypagi.getTotal().toString());
				
				totalpage = mypagi.getTotalpage();
				
				pageno = mypagi.getPage();
				
				if(pageno - 1 <= 0)
				{
					prepage = 1;
				}
				else
				{
					prepage = pageno - 1 ;
				}
				
				
				if(pageno + 1 > totalpage)
				{
					nextpage = totalpage;
				}
				else
				{
					nextpage = pageno + 1 ;
				}
				
			}			
			
		}
		catch(Exception ex)
		{
			System.out.println("GuideAction.query() Script error: " + ex.toString());			
		}
		
		return "list";
	}

	
}
