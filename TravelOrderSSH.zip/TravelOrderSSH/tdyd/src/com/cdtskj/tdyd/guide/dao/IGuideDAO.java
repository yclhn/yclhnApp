package com.cdtskj.tdyd.guide.dao;

import com.cdtskj.pojo.LyGuide;
import com.cdtskj.xt.base.IBaseDAO;

public interface IGuideDAO extends IBaseDAO<LyGuide>
{

}
