package com.cdtskj.tdyd.guide.service.impl;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.cdtskj.pojo.LyGuide;
import com.cdtskj.tdyd.agency.dao.IAgencyDAO;
import com.cdtskj.tdyd.guide.dao.IGuideDAO;
import com.cdtskj.tdyd.guide.service.IGuideService;
import com.cdtskj.util.Pagination;

public class GuideServiceImpl implements IGuideService
{
	
	private IGuideDAO dao;
	
	private IAgencyDAO agencyDao;
	

	public IGuideDAO getDao() 
	{
		return dao;
	}

	public void setDao(IGuideDAO dao) 
	{
		this.dao = dao;
	}
	
	

	public IAgencyDAO getAgencyDao() 
	{
		return agencyDao;
	}

	public void setAgencyDao(IAgencyDAO agencyDao) 
	{
		this.agencyDao = agencyDao;
	}

	
	
	
	
	public void addGuide(LyGuide guide)
	{
		try
		{
			 this.dao.save(guide);		 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("GuideServiceImpl.addGuide() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void updateGuide(LyGuide guide)  
	{	
		
		try
		{ 
			LyGuide guide2 = this.dao.get(LyGuide.class, guide.getGuideid());
			
			BeanUtils.copyProperties(guide2, guide);
			
			this.dao.update(guide2);	 			 
			
		}
		catch(Exception ex)
		{
			System.out.println("GuideServiceImpl.updateGuide() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteGuide(LyGuide guide)
	{
		try
		{ 
			 this.dao.delete(this.dao.get(LyGuide.class, guide.getGuideid()));			 			  
		}
		catch(Exception ex)
		{
			System.out.println("GuideServiceImpl.deleteGuide() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyGuide queryGuideById(Integer id)
	{
		 LyGuide guide=this.dao.get(LyGuide.class, id);	 		  
		 
		 return guide;
	}
	
	
	
	public List<LyGuide> querySuitableGuides()
	{
		 List<LyGuide> guides=this.dao.find("from LyGuide");
		 		 
		 return guides;
	}
	
	
	
	public Pagination queryPaginationGuide(LyGuide guide, Integer page, Integer rows)
	{		 
		
		Pagination mypagi = null;
		
		try
		{
			String strHQL = "from LyGuide where name like ? AND sex like ?";
			
			String[] param = new String [] {"%" + guide.getName() + "%" , "%" + guide.getSex() + "%"};
			
			mypagi = this.dao.find(strHQL, param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println("GuideServiceImpl.queryPaginationGuide() Script error: " + ex.toString());
		}
				
		return mypagi;
		
	}

}
