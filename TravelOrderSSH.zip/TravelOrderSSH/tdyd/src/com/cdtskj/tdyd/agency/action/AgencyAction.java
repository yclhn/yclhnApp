package com.cdtskj.tdyd.agency.action;

import java.util.List;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.tdyd.agency.service.impl.AgencyServiceImpl;
import com.cdtskj.util.Pagination;
import com.opensymphony.xwork2.ActionSupport;


public class AgencyAction extends ActionSupport
{
	
	private IAgencyService agencyService;
	
	private Integer agencyid;
	
	private String name;	

	private String code;
	
	private List<LyAgency> list ;
	
	private LyAgency agency;
	
	
	private Integer pageno;
	
	private Integer totalpage;
	
	private Integer totalrow;
	
	private Integer pageSize;
	
	private Integer nextpage;
	
	private Integer prepage;
	
	
	
	
	
	
	
	public IAgencyService getAgencyService() 
	{
		return agencyService;
	}

	public void setAgencyService(IAgencyService agencyService) 
	{
		this.agencyService = agencyService;
	}
	
	
	

	public Integer getNextpage() {
		return nextpage;
	}

	public void setNextpage(Integer nextpage) {
		this.nextpage = nextpage;
	}

	public Integer getPrepage() {
		return prepage;
	}

	public void setPrepage(Integer prepage) {
		this.prepage = prepage;
	}

	public Integer getAgencyid() 
	{
		return agencyid;
	}

	public void setAgencyid(Integer agencyid) 
	{
		this.agencyid = agencyid;
	}

	public List<LyAgency> getList() 
	{
		return list;
	}

	public void setList(List<LyAgency> list) 
	{
		this.list = list;
	}

	public LyAgency getAgency() 
	{
		return agency;
	}

	public void setAgency(LyAgency agency) 
	{
		this.agency = agency;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public String getCode() 
	{
		return code;
	}

	public void setCode(String code) 
	{
		this.code = code;
	}
	
	
	
	
	public Integer getPageno() 
	{
		return pageno;
	}

	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}

	public Integer getTotalpage() 
	{
		return totalpage;
	}

	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}

	public Integer getTotalrow() 
	{
		return totalrow;
	}

	public void setTotalrow(Integer totalrow) 
	{
		this.totalrow = totalrow;
	}
	
	
	
	
	
	

	public String save()
	{
		if (agency.getAgencyid()!=null)
		{
			agencyService.updateAgency(agency);
		}
		else
		{
			agencyService.addAgency(agency);
		}
		
		return "list";
	}
	
	
	public String delete()
	{
		try
		{
			if(agencyid!=null)
			{				
				LyAgency tempAgency = new LyAgency();
				
				tempAgency.setAgencyid(agencyid);
				
				agencyService.deleteAgency(tempAgency);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("AgencyAction.delete() Script error : " + ex.toString());
			
		}
		
		return "list";
	}
	
	
	
	public String edit()
	{
		agency = agencyService.queryAgencyById(agencyid);			 
		
		return "data";
	}
	
	
	 
	
	
	public String query()
	{
		try
		{
			LyAgency tempAgency = new LyAgency();
			
			if(code==null)
			{
				code="";
			}
			
			tempAgency.setCode(code);
			
			if(name==null)
			{
				name="";
			}
			
			tempAgency.setName(name);
			
			Pagination mypagi = agencyService.queryPaginationAgency(tempAgency, pageno, pageSize);
			
			if(mypagi != null)
			{				
				list=(List<LyAgency>)mypagi.getRows();
				
				totalrow =Integer.parseInt( mypagi.getTotal().toString());
				
				totalpage = mypagi.getTotalpage();
				
				pageno = mypagi.getPage();
				
				if(pageno - 1 <= 0)
				{
					prepage = 1;
				}
				else
				{
					prepage = pageno - 1 ;
				}
				
				
				if(pageno + 1 > totalpage)
				{
					nextpage = totalpage;
				}
				else
				{
					nextpage = pageno + 1 ;
				}
				
			}			
			
		}
		catch(Exception ex)
		{
			System.out.println("AgencyAction.query() Script error: " + ex.toString());			
		}
		
		return "list";
	}

	
}
