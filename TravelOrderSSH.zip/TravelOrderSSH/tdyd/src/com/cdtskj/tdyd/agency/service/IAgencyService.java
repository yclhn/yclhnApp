package com.cdtskj.tdyd.agency.service;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.util.Pagination;
import java.util.*;

public interface IAgencyService 
{
	
	public void addAgency(LyAgency agency);
	
	public void updateAgency(LyAgency agency);
	
	public void deleteAgency(LyAgency agency);
	
	
	
	public LyAgency queryAgencyById(Integer id);
	
	public List<LyAgency> querySuitableAgencys();
	
	public Pagination queryPaginationAgency(LyAgency agency, Integer page, Integer rows);
	
	
}
