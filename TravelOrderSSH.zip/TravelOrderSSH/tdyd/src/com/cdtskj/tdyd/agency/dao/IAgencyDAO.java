package com.cdtskj.tdyd.agency.dao;

import com.cdtskj.pojo.*;
import com.cdtskj.xt.base.IBaseDAO;

public interface IAgencyDAO extends IBaseDAO<LyAgency>
{

}
