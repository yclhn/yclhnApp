package com.cdtskj.tdyd.agency.dao.impl;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.tdyd.agency.dao.IAgencyDAO;
import com.cdtskj.xt.base.BaseDAOImpl;

public class AgencyDAOImpl extends BaseDAOImpl<LyAgency> implements IAgencyDAO 
{

}
