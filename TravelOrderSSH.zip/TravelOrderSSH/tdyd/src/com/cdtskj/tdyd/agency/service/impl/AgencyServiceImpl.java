package com.cdtskj.tdyd.agency.service.impl;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.Transaction;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.tdyd.agency.dao.IAgencyDAO;
import com.cdtskj.tdyd.agency.dao.impl.AgencyDAOImpl;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.util.HibernateUtil;
import com.cdtskj.util.Pagination;

public class AgencyServiceImpl implements IAgencyService 
{
	
	private IAgencyDAO dao;
	
	

	public IAgencyDAO getDao() 
	{
		return dao;
	}

	public void setDao(IAgencyDAO dao) 
	{
		this.dao = dao;
	}
	
	

	public void addAgency(LyAgency agency)
	{
		try
		{
		 		 
		 this.dao.save(agency);	 
		  
		 
		}
		catch(Exception ex)
		{
			System.out.println("AgencyServiceImpl.addAgency() Script error: " + ex.toString());
		}
	}
	
	
	
	public void updateAgency(LyAgency agency)  
	{
		
		
		try
		{
			 	 
			 
			LyAgency agency2 = this.dao.get(LyAgency.class, agency.getAgencyid());
			
			BeanUtils.copyProperties(agency2, agency);
			
			this.dao.update(agency2);	
		 
			 
		 
		}
		catch(Exception ex)
		{
			System.out.println("AgencyServiceImpl.updateAgency() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteAgency(LyAgency agency)
	{
		try
		{
			 
			 
			 this.dao.delete(this.dao.get(LyAgency.class, agency.getAgencyid()));
			 
			  
		}
		catch(Exception ex)
		{
			System.out.println("AgencyServiceImpl.deleteAgency() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyAgency queryAgencyById(Integer id)
	{		  
		 
		 LyAgency agency=this.dao.get(LyAgency.class, id);		 
		  
		 
		 return agency;
	}
	
	
	
	public List<LyAgency> querySuitableAgencys()
	{		 
		 
		 List<LyAgency> agencys=this.dao.find("from LyAgency");		 
		  
		 
		 return agencys;
	}
	
	
	
	public Pagination queryPaginationAgency(LyAgency agency, Integer page, Integer rows)
	{
		 
		
		Pagination mypagi = null;
		
		try
		{
			String strHQL = "from LyAgency where name like ? AND code like ?";
			
			String[] param = new String [] {"%" + agency.getName() + "%" , "%" + agency.getCode() + "%"};
			
			mypagi = this.dao.find(strHQL, param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.toString());
		}
		
		 
		
		return mypagi;
	}
	
	
}
