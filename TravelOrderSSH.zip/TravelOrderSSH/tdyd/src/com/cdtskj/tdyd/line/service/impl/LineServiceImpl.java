package com.cdtskj.tdyd.line.service.impl;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.Transaction;
import com.cdtskj.pojo.LyLine;
import com.cdtskj.tdyd.line.dao.ILineDAO;
import com.cdtskj.tdyd.line.dao.impl.LineDAOImpl;
import com.cdtskj.tdyd.line.service.ILineService;
import com.cdtskj.util.HibernateUtil;
import com.cdtskj.util.Pagination;



public class LineServiceImpl implements ILineService
{
	
	private ILineDAO dao;
	
	
	public ILineDAO getDao() 
	{
		return dao;
	}


	public void setDao(ILineDAO dao) 
	{
		this.dao = dao;
	}



	public void addLine(LyLine Line)
	{
		try
		{
			 this.dao.save(Line);		 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("LineServiceImpl.addLine() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void updateLine(LyLine line)  
	{	
		
		try
		{ 
			LyLine line2 = this.dao.get(LyLine.class, line.getLineid());
			
			BeanUtils.copyProperties(line2, line);
			
			this.dao.update(line2);	 			 
			
		}
		catch(Exception ex)
		{
			System.out.println("LineServiceImpl.updateLine() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteLine(LyLine line)
	{
		try
		{ 
			 this.dao.delete(this.dao.get(LyLine.class, line.getLineid()));			 			  
		}
		catch(Exception ex)
		{
			System.out.println("LineServiceImpl.deleteLine() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyLine queryLineById(Integer id)
	{
		 LyLine line=this.dao.get(LyLine.class, id);	 		  
		 
		 return line;
	}
	
	
	
	public List<LyLine> querySuitableLines()
	{
		 List<LyLine> lines=this.dao.find("from LyLine");
		 		 
		 return lines;
	}
	
	
	
	public Pagination queryPaginationLine(LyLine line, Integer page, Integer rows)
	{		 
		
		Pagination mypagi = null;
		
		try
		{
			String strHQL = "from LyLine where name like ? AND code like ?";
			
			String[] param = new String [] {"%" + line.getName() + "%" , "%" + line.getCode() + "%"};
			
			mypagi = this.dao.find(strHQL, param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println("LineServiceImpl.queryPaginationLine() Script error: " + ex.toString());
		}
				
		return mypagi;
		
	}
	

}
