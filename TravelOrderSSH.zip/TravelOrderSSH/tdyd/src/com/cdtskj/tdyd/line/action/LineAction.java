package com.cdtskj.tdyd.line.action;

import java.util.List;

import com.cdtskj.pojo.LyLine;
import com.cdtskj.tdyd.line.service.ILineService;
import com.cdtskj.tdyd.line.service.impl.LineServiceImpl;
import com.cdtskj.util.Pagination;
import com.opensymphony.xwork2.ActionSupport;




public class LineAction extends ActionSupport
{
	
	private ILineService lineService;
	
	private Integer lineid;
	
	private String name;	

	private String code;
	
	private List<LyLine> list ;
	
	private LyLine line;
	
	
	private Integer pageno;
	
	private Integer totalpage;
	
	private Integer totalrow;
	
	private Integer pageSize;
	
	private Integer nextpage;
	
	private Integer prepage;
	
	
	 
	

	public ILineService getLineService() 
	{
		return lineService;
	}


	public void setLineService(ILineService lineService) 
	{
		this.lineService = lineService;
	}


	
	
	public Integer getLineid() 
	{
		return lineid;
	}


	public void setLineid(Integer lineid) 
	{
		this.lineid = lineid;
	}


	public String getName() 
	{
		return name;
	}


	public void setName(String name) 
	{
		this.name = name;
	}


	public String getCode() 
	{
		return code;
	}


	public void setCode(String code) 
	{
		this.code = code;
	}


	public List<LyLine> getList() 
	{
		return list;
	}


	public void setList(List<LyLine> list) 
	{
		this.list = list;
	}


	public LyLine getLine() 
	{
		return line;
	}


	public void setLine(LyLine line) 
	{
		this.line = line;
	}


	public Integer getPageno() 
	{
		return pageno;
	}


	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}


	public Integer getTotalpage() 
	{
		return totalpage;
	}


	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}


	public Integer getTotalrow() 
	{
		return totalrow;
	}


	public void setTotalrow(Integer totalrow) 
	{
		this.totalrow = totalrow;
	}


	public Integer getNextpage() 
	{
		return nextpage;
	}


	public void setNextpage(Integer nextpage) 
	{
		this.nextpage = nextpage;
	}


	public Integer getPrepage() 
	{
		return prepage;
	}


	public void setPrepage(Integer prepage) 
	{
		this.prepage = prepage;
	}
	
	
	
	


	public String save()
	{
		if (line.getLineid()!=null)
		{
			lineService.updateLine(line);
		}
		else
		{
			lineService.addLine(line);
		}
		
		return "list";
	}
	
	
	public String delete()
	{
		try
		{
			if(lineid!=null)
			{				
				LyLine tempLine = new LyLine();
				
				tempLine.setLineid(lineid);
				
				lineService.deleteLine(tempLine);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("LineAction.delete() Script error : " + ex.toString());
			
		}
		
		return "list";
	}
	
	
	
	public String edit()
	{
		line = lineService.queryLineById(lineid);			 
		
		return "data";
	}
	
	
	 
	
	
	public String query()
	{
		try
		{
			LyLine tempLine = new LyLine();
			
			if(code==null)
			{
				code="";
			}
			
			tempLine.setCode(code);
			
			if(name==null)
			{
				name="";
			}
			
			tempLine.setName(name);
			
			Pagination mypagi = lineService.queryPaginationLine(tempLine, pageno, pageSize);
			
			if(mypagi != null)
			{				
				list=(List<LyLine>)mypagi.getRows();
				
				totalrow =Integer.parseInt( mypagi.getTotal().toString());
				
				totalpage = mypagi.getTotalpage();
				
				pageno = mypagi.getPage();
				
				if(pageno - 1 <= 0)
				{
					prepage = 1;
				}
				else
				{
					prepage = pageno - 1 ;
				}
				
				
				if(pageno + 1 > totalpage)
				{
					nextpage = totalpage;
				}
				else
				{
					nextpage = pageno + 1 ;
				}
				
			}			
			
		}
		catch(Exception ex)
		{
			System.out.println("LineAction.query() Script error: " + ex.toString());			
		}
		
		return "list";
	}

}
