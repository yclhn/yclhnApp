package com.cdtskj.tdyd.order.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.LyGuide;
import com.cdtskj.pojo.LyLine;
import com.cdtskj.pojo.LyOrder;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.tdyd.guide.service.IGuideService;
import com.cdtskj.tdyd.line.service.ILineService;
import com.cdtskj.tdyd.order.service.IOrderService;
import com.cdtskj.util.Pagination;
import com.opensymphony.xwork2.ActionSupport;

import org.apache.commons.io.FileUtils;

public class OrderAction extends ActionSupport
{
	
	private IOrderService orderService;
	
	private IAgencyService agencyService;
	
	private ILineService lineService;
	
	private IGuideService guideService;
	
	
	List<LyAgency> listAgency;
	
	List<LyLine> listLine;
	
	List<LyGuide> listGuide;
	
	
	
	
	private Integer orderid;
	
	private String remark;	

	private String title;
	
	private List<LyOrder> list ;
	
	private LyOrder order;
	
	
	private Integer pageno;
	
	private Integer totalpage;
	
	private Integer totalrow;
	
	private Integer pageSize;
	
	private Integer nextpage;
	
	private Integer prepage;
	
		

	private File upload;
	
	private String uploadFileName;
	
	private String uploadContentType;

	 
	
	private String downfilename;
	
	


	public String getDownfilename() 
	{
		return downfilename;
	}


	public void setDownfilename(String downfilename) 
	{
		this.downfilename = downfilename;
	}


	public File getUpload() 
	{
		return upload;
	}


	public void setUpload(File upload) 
	{
		this.upload = upload;
	}


	public String getUploadFileName() 
	{
		return uploadFileName;
	}


	public void setUploadFileName(String uploadFileName)
	{
		this.uploadFileName = uploadFileName;
	}


	public String getUploadContentType() 
	{
		return uploadContentType;
	}


	public void setUploadContentType(String uploadContentType) 
	{
		this.uploadContentType = uploadContentType;
	}


	public IOrderService getOrderService() 
	{
		return orderService;
	}


	public void setOrderService(IOrderService orderService) 
	{
		this.orderService = orderService;
	}


	public IAgencyService getAgencyService() 
	{
		return agencyService;
	}


	public void setAgencyService(IAgencyService agencyService) 
	{
		this.agencyService = agencyService;
	}


	public ILineService getLineService() 
	{
		return lineService;
	}


	public void setLineService(ILineService lineService) 
	{
		this.lineService = lineService;
	}


	public IGuideService getGuideService() 
	{
		return guideService;
	}


	public void setGuideService(IGuideService guideService) 
	{
		this.guideService = guideService;
	}


	public List<LyAgency> getListAgency() 
	{
		return listAgency;
	}


	public void setListAgency(List<LyAgency> listAgency) 
	{
		this.listAgency = listAgency;
	}


	public List<LyLine> getListLine() 
	{
		return listLine;
	}


	public void setListLine(List<LyLine> listLine) 
	{
		this.listLine = listLine;
	}


	public List<LyGuide> getListGuide() 
	{
		return listGuide;
	}


	public void setListGuide(List<LyGuide> listGuide) 
	{
		this.listGuide = listGuide;
	}


	public Integer getOrderid() 
	{
		return orderid;
	}


	public void setOrderid(Integer orderid) 
	{
		this.orderid = orderid;
	}


	public String getRemark() 
	{
		return remark;
	}


	public void setRemark(String remark) 
	{
		this.remark = remark;
	}


	public String getTitle() 
	{
		return title;
	}


	public void setTitle(String title) 
	{
		this.title = title;
	}


	public List<LyOrder> getList() 
	{
		return list;
	}


	public void setList(List<LyOrder> list) 
	{
		this.list = list;
	}


	public Integer getPageno() 
	{
		return pageno;
	}


	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}


	public Integer getTotalpage() 
	{
		return totalpage;
	}


	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}


	public Integer getTotalrow() 
	{
		return totalrow;
	}


	public void setTotalrow(Integer totalrow) 
	{
		this.totalrow = totalrow;
	}


	public Integer getNextpage() 
	{
		return nextpage;
	}


	public void setNextpage(Integer nextpage) 
	{
		this.nextpage = nextpage;
	}


	public Integer getPrepage() 
	{
		return prepage;
	}


	public void setPrepage(Integer prepage) 
	{
		this.prepage = prepage;
	}


	public LyOrder getOrder() 
	{
		return order;
	}


	public void setOrder(LyOrder order) 
	{
		this.order = order;
	}


	
	
	
	public String save()
	{
		if (order.getOrderid()!=null)
		{
			orderService.updateOrder(order);
		}
		else
		{
			order.setZt("apply");
			
			orderService.addOrder(order);
		}
		
		return "list";
	}
	
	
	
	
	public String delete()
	{
		try
		{
			if(orderid!=null)
			{				
				LyOrder tempOrder = new LyOrder();
				
				tempOrder.setOrderid(orderid);
				
				orderService.deleteOrder(tempOrder);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.delete() Script error : " + ex.toString());			
		}
		
		return "list";
	}
	
	
	
	public String edit()
	{
		try
		{
			order = orderService.queryOrderById(orderid);	
			
			listAgency = agencyService.querySuitableAgencys();
			
			listLine = lineService.querySuitableLines();
			
			listGuide = guideService.querySuitableGuides();
			
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.edit() Script error : " + ex.toString());			
		}
		
		return "data";
	}
	
	
	
	public String add()
	{
		try
		{
			listAgency = agencyService.querySuitableAgencys();
			
			listLine = lineService.querySuitableLines();
			
			listGuide = guideService.querySuitableGuides();
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.add() Script error : " + ex.toString());			
		}
		
		return "data";
	}
	
	
	
	public String query()
	{
		try
		{
			LyOrder tempOrder = new LyOrder();
			
			if(title==null)
			{
				title="";
			}
			
			tempOrder.setTitle(title); 
			
			if(remark==null)
			{
				remark="";
			}
			
			tempOrder.setRemark(remark);
			
			Pagination mypagi = orderService.queryPaginationOrder(tempOrder, pageno, pageSize);
			
			if(mypagi != null)
			{				
				list=(List<LyOrder>)mypagi.getRows();
				
				totalrow =Integer.parseInt( mypagi.getTotal().toString());
				
				totalpage = mypagi.getTotalpage();
				
				pageno = mypagi.getPage();
				
				if(pageno - 1 <= 0)
				{
					prepage = 1;
				}
				else
				{
					prepage = pageno - 1 ;
				}
				
				
				if(pageno + 1 > totalpage)
				{
					nextpage = totalpage;
				}
				else
				{
					nextpage = pageno + 1 ;
				}
				
			}			
			
		}
		catch(Exception ex)
		{
			System.out.println("OrderAction.query() Script error: " + ex.toString());			
		}
		
		return "list";
	}
	
	
	public void applyOrder()
	{
		
		try
		{
			 order.setZt("apply");
			 
			 this.orderService.applyOrder(order);
			 
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.applyOrder() Script error : " + ex.toString());			
		}
		
	}
	
	public String upload()
	{
		order = orderService.queryOrderById(order.getOrderid());
		
		return "upload";
	}
	
	
	
	public String uploadFile()
	{
		String strFile="",strFilename="";
		String strPath="D:/UplodJavaData";
		
		try
		{
			if(upload != null)
			{
				
				//1.Get dest filename
				
				SimpleDateFormat myfmt =new SimpleDateFormat("yyyyMMddHHmmssSSS");
				
				Date mydt = new Date();
				
				strFilename = myfmt.format(mydt);
				
				strFilename = strFilename + 
						      this.uploadFileName.substring(uploadFileName.lastIndexOf("."), uploadFileName.length());
				
				//2.Creat dest file
				
				strFile = strPath+ "/" + strFilename;
								
				File destFile = new File(strFile);								 
				
				FileUtils.copyFile(upload, destFile);   
				
				
				//3.Set order filename
				
				order.setFilename(uploadFileName);
				
				order.setRealfilename(strFilename);				
				
				this.orderService.updateOrderFilename(order);
				
				return "list";
				
			}
			else
			{
				return "upload";
			}
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.uploadFile() Script error : " + ex.toString());			
		}
		
		
		return "upload";
	}
	
	
	public String examinePass()
	{
		try
		{
			this.orderService.examinePass(order);
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.examinePass() Script error : " + ex.toString());			
		}
		
 		return "list";
	}
	
	
	public String exam()
	{
		try
		{
			order = this.orderService.queryOrderById(order.getOrderid());
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.examinePass() Script error : " + ex.toString());			
		}
		
		return "exam";
	}
	
	
	public InputStream getTargetFile()
	{
		
		String strFilename="",strFile="";		
		String strPath="";
		FileInputStream fis=null;
		
		try
		{
			strPath = "D:/UplodJavaData";
			
			LyOrder tempOrder  = this.orderService.queryOrderById(orderid);
			
			strFilename = tempOrder.getRealfilename();
			
			this.downfilename=tempOrder.getFilename();
			
			strFile = strPath + "/" + strFilename;
			
			HttpServletRequest request = ServletActionContext.getRequest();
			
			File fileData = new File(strFile);
			
			fis= new FileInputStream(fileData);			
			
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.getTargetFile() Script error : " + ex.toString());			
		}
		
		return fis;
		
	}
	
	
	public String downloadFile()	
	{
		return "success";
	}
	
	
	public String getTargetContenetType()
	{
		String strContentType = "";
		
		try
		{
			strContentType = ServletActionContext.getServletContext().getMimeType(downfilename);
		}
		catch(Exception ex )
		{
			System.out.println("OrderAction.getTargetContenetType() Script error : " + ex.toString());			
		}
		
		return  strContentType;
	}
	
}
