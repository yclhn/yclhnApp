package com.cdtskj.tdyd.order.service;

import java.util.List;

import com.cdtskj.pojo.LyOrder;
import com.cdtskj.util.Pagination;

public interface IOrderService 
{
	
	public void addOrder(LyOrder order);
	
	public void updateOrder(LyOrder order);
	
	public void deleteOrder(LyOrder order);
	
	
	
	public LyOrder queryOrderById(Integer id);	 
	
	public Pagination queryPaginationOrder(LyOrder order, Integer page, Integer rows);
	
	
	public void applyOrder(LyOrder order);
	
	public void examinePass(LyOrder order);
	
	public void updateOrderFilename(LyOrder order);
	

}
