package com.cdtskj.tdyd.order.service.impl;

import org.apache.commons.beanutils.BeanUtils;

import com.cdtskj.pojo.LyOrder;
import com.cdtskj.tdyd.order.dao.IOrderDAO;
import com.cdtskj.tdyd.order.service.IOrderService;
import com.cdtskj.util.Pagination;

public class OrderServiceImpl implements IOrderService
{
	
	private IOrderDAO dao;
	
	
	
	public IOrderDAO getDao() 
	{
		return dao;
	}


	public void setDao(IOrderDAO dao) 
	{
		this.dao = dao;
	}



	public void addOrder(LyOrder order)
	{
		try
		{
			 this.dao.save(order);		 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("OrderServiceImpl.addOrder() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void updateOrder(LyOrder order)  
	{	
		
		try
		{ 
			LyOrder order2 = this.dao.get(LyOrder.class, order.getOrderid());
			
			BeanUtils.copyProperties(order2, order);
			
			this.dao.update(order2);	 			 
			
		}
		catch(Exception ex)
		{
			System.out.println("OrderServiceImpl.updateOrder() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteOrder(LyOrder order)
	{
		try
		{ 
			 this.dao.delete(this.dao.get(LyOrder.class, order.getOrderid()));			 			  
		}
		catch(Exception ex)
		{
			System.out.println("OrderServiceImpl.deleteOrder() Script error: " + ex.toString());
		}	
	}
	
	
	
	public LyOrder queryOrderById(Integer id)
	{
		 LyOrder order=this.dao.get(LyOrder.class, id);	 		  
		 
		 return order;
	}
	
	
	 
	
	
	public Pagination queryPaginationOrder(LyOrder order, Integer page, Integer rows)
	{		 
		
		Pagination mypagi = null;
		
		try
		{
			String strHQL = "from LyOrder where title like ? AND remark like ?";
			
			String[] param = new String [] {"%" + order.getTitle() + "%" , "%" + order.getRemark() + "%"};
			
			mypagi = this.dao.find(strHQL, param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println("OrderServiceImpl.queryPaginationOrder() Script error: " + ex.toString());
		}
				
		return mypagi;
		
	}
	
	
	
	
	
	public void applyOrder(LyOrder order)
	{
		LyOrder orderTemp = this.dao.get(LyOrder.class, order.getOrderid());
		
		orderTemp.setZt(order.getZt());
		
		this.dao.update(orderTemp);
	}
	
	
	
	public void examinePass(LyOrder order)
	{
		
		LyOrder updateOrder = this.dao.get(LyOrder.class, order.getOrderid());
		
		updateOrder.setZt(order.getZt());
		
		updateOrder.setRemark(order.getRemark());
		
		this.dao.update(updateOrder);
		
	}
	
	
	
	public void updateOrderFilename(LyOrder order)
	{
		LyOrder tempOrder = this.dao.get(LyOrder.class, order.getOrderid());
		
		tempOrder.setFilename(order.getFilename());
		
		tempOrder.setRealfilename(order.getRealfilename());
		
		this.dao.update(tempOrder);
				
	}

}
