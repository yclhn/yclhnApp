package com.cdtskj.xt.login.action;

import com.cdtskj.pojo.XtUser;
import com.cdtskj.xt.user.service.IUserService;
import com.cdtskj.xt.user.service.impl.UserServiceImpl;
import com.opensymphony.xwork2.ActionSupport;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import org.apache.struts2.ServletActionContext;

public class LoginAction extends ActionSupport
{
	private String loginName;
	
	private String password;
	
	private XtUser user;
	
	private IUserService  userService ;
	
	
	
	
	
	public IUserService getUserService() 
	{
		return userService;
	}

	public void setUserService(IUserService userService) 
	{
		this.userService = userService;
	}
	
	

	public XtUser getUser() 
	{
		return user;
	}

	public void setUser(XtUser user) 
	{
		this.user = user;
	}

	public String getLoginName() 
	{
		return loginName;
	}

	public void setLoginName(String loginName) 
	{
		this.loginName = loginName;
	}
	
	
	

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}
	
	
	public String execute() throws Exception
	{
		
		String strLogontime="";	
		
		List<XtUser> list=null;
		
		try
		{
		
			list=userService.login(user);
			
			if(list.size() > 0)		 
			{				
				
				ServletActionContext.getRequest().getSession().setAttribute("userid", user.getLoginname());
				
				SimpleDateFormat myfmt =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				Date mydt = new Date();
				
				strLogontime = myfmt.format(mydt);
				
				ServletActionContext.getRequest().getSession().setAttribute("logontime",strLogontime );
				
				ServletActionContext.getRequest().getSession().setAttribute("user",user );
				
				System.out.println("Log successfully, User is :" + user.getLoginname() + ", loginTime is :" + strLogontime);				
								
				return "success";
			}
			else
			{
				return "login";
			}	
			
		}		
		catch(Exception ex)
		{
			System.out.println("LoginAction.execute() Script Error: " + ex.toString());
		}
		
		return "login";
		
	}
	
	
	
	
	public String executeold() throws Exception
	{
		
		
		
		//1.Dim variable
	
		Connection mycon=null;
		String strCon="",strData="";
		String strLogontime="";		 
		
		try
		{
			
			//2.Get connection
			
			Class.forName("com.mysql.jdbc.Driver");
			
			strCon= "jdbc:mysql://127.0.0.1:3306/tdyd?"+ 
			"user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
			
			mycon= DriverManager.getConnection(strCon);
			
			
			//3.Get data			
			
			strData= "select * from xt_user where loginname=? and password=?";
			
			PreparedStatement ps= mycon.prepareStatement(strData);
			
			ps.setString(1, loginName);
			
			ps.setString(2, password);
			
			ResultSet rs= ps.executeQuery();
			
			
			//4.Return data
			
			if (rs.next()) 
			{				
				
				ServletActionContext.getRequest().getSession().setAttribute("userid", loginName);
				
				SimpleDateFormat myfmt =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				Date mydt = new Date();
				
				strLogontime = myfmt.format(mydt);
				
				ServletActionContext.getRequest().getSession().setAttribute("logontime",strLogontime );
				
				System.out.println("Log successfully, User is :" + loginName);				
								
				return "success";
			}
			else
			{
				return "login";
			}					
			
		}
		catch(Exception ex)
		{
			System.out.println("LoginAction.execute() Script Error: " + ex.toString());
		}
		finally
		{
			if(mycon!=null)
			{
				mycon.close();
			}
			
		}
		
		return "login";
	}

	
}
