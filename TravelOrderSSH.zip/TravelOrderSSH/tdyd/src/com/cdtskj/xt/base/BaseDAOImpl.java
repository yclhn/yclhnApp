package com.cdtskj.xt.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.SessionFactory;

import com.cdtskj.util.HibernateUtil;
import com.cdtskj.util.Pagination;

public class BaseDAOImpl<T> implements IBaseDAO<T>
{

	private SessionFactory sessionFactory;
	

	public SessionFactory getSessionFactory() 
	{
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	
	
	
	
	public Session getCurrentSession()
	{
		return sessionFactory.getCurrentSession();
	}
	
	
	
	public Serializable save(T entity)
	{
		Serializable sa=null;
		
		try
		{
			Session session = sessionFactory.getCurrentSession();
			
			sa=session.save(entity);
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.save() Script error: " + ex.toString());
		}
		
		return sa;			 
	}
	
	
	
	
	public void update(T entity)
	{
		try
		{
			Session session = sessionFactory.getCurrentSession();
			
			session.update(entity);
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.update() Script error: " + ex.toString());
		}
		
		
	}
	
	
	
	public void delete(T entity)
	{
		try
		{
			Session session = sessionFactory.getCurrentSession();
			
			session.delete(entity);
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.delete() Script error: " + ex.toString());
		}
	}
	
	
	
	
	public void saveOrUpdate(T entity)
	{
		Session session = sessionFactory.getCurrentSession();
		
		session.saveOrUpdate(entity);
	}
	
	
	
	public List<T>find(String hql)
	{
		Session session = sessionFactory.getCurrentSession();
		
		List list=session.createQuery(hql).list();
		
		return list;
	}
	
	
	
	
	public List<T>find(String hql, Object[] param)
	{
		Session session = sessionFactory.getCurrentSession();
		
		Query  qryData=null;
		
		List<T> list=null;
		
		try
		{
			qryData= session.createQuery(hql);					
		
			if(param != null)
			{
			
				if(param.length > 0)
				{
					for(int intK=0; intK<param.length; intK++)
					{
						qryData.setParameter(intK, param[intK]);
					}
				}
			}
			
		    list=qryData.list();		
		
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error: " + ex.toString());
		}
		
		return list;
	}
	
	
	
	
	
	public List<T>find(String hql, List<Object> param)
	{
		Session session = sessionFactory.getCurrentSession();
		
		Query  qryData=null;
		
		List<T> list=null;
		
		try
		{
			
			qryData= session.createQuery(hql);			
		
		
			if(param != null)
			{
			
				if(param.size() > 0)
				{
					for(int intK=0; intK<param.size(); intK++)
					{
						qryData.setParameter(intK, param.get(intK));
					}
				}
			}
			
			list=qryData.list();
		
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error: " + ex.toString());
		}
		
		return list;
	}
	
	
	
	public Pagination find(String hql,Object[] param,Integer page, Integer rows) throws Exception
	{
		Session session = sessionFactory.getCurrentSession();
		
		long lgTotal=(long)0;
		
		List list=null;
		
		int totalpage = 0;
		
		
		try
		{
		
			//1.Set page
			
			if(page ==null || page < 1)
			{
				page = 1;
			}
			
			//2.Set row
			
			if(rows == null || rows < 1)
			{
				rows = 3;
			}
			
			
			//3.Check HQL			
			 
			
			int intFrom = hql.indexOf("from");
			
			if(intFrom == -1)
			{
				throw new Exception("Failed HQL, Not include 'from'");
			}
			
			
			//4.Get total row
			
			String strHQL="select count(*) "  + hql.substring(intFrom);
			
			Query qryData = this.getCurrentSession().createQuery(strHQL);
			
			if(param!=null)
			{
				if(param.length>0)
				{
	
					for(int intK=0; intK<param.length; intK++)
					{
						qryData.setParameter(intK, param[intK]);
					}
				}
			}
			
			lgTotal = ((Long)qryData.uniqueResult()).longValue();
			
			if(lgTotal < 1L)
			{
				return new Pagination(0L,0,Collections.EMPTY_LIST,0);
			}
			
			
			//5.Get data
			
			Query qryData1 = this.getCurrentSession().createQuery(hql);
			
			if(param!=null)
			{
				if(param.length>0)
				{
	
					for(int intK=0; intK<param.length; intK++)
					{
						qryData1.setParameter(intK, param[intK]);
					}
				}
			}
			
			
		    list=qryData1.setFirstResult((page-1) * rows).setMaxResults(rows).list();	
		    
		    if(lgTotal % rows ==  0)
		    {
		    	totalpage =(int)(lgTotal/rows);
		    }
		    else
		    {
		    
		    	totalpage =((int) (lgTotal/rows) ) + 1;
		    }
		
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
		
		 
		return new Pagination(lgTotal,page,list,totalpage);
		
	}
	
	
	
	public Pagination find(String hql,List<Object> param,Integer page, Integer rows) throws Exception
	{
		Session session = sessionFactory.getCurrentSession();
		
		long lgTotal=(long)0;
		
		List list=null;
		
		int totalpage=0;
		
		try		
		{
		
			//1.Set page
			
			if(page ==null || page < 1)
			{
				page = 1;
			}
			
			//2.Set row
			
			if(rows == null || rows < 1)
			{
				rows = 10;
			}
			
			
			//3.Check HQL 
			
			hql=hql.toLowerCase();
			
			int intFrom = hql.indexOf("from");
			
			if(intFrom == -1)
			{
				throw new Exception("Failed HQL, Not include 'from'");
			}
			
			
			//4.Get total row
			
			String strHQL="select count(*) "  + hql.substring(intFrom);
			
			Query qryData = this.getCurrentSession().createQuery(strHQL);
			
			if(param!=null)
			{
				if(param.size()>0)
				{
	
					for(int intK=0; intK<param.size(); intK++)
					{
						qryData.setParameter(intK, param.get(intK));
					}
				}
			}
			
			lgTotal = ((Long)qryData.uniqueResult()).longValue();
			
			if(lgTotal < 1L)
			{
				return new Pagination(0L,0,Collections.EMPTY_LIST,0);
			}
			
			
			//5.Get data
			
			Query qryData1 = this.getCurrentSession().createQuery(hql);
			
			if(param!=null)
			{
				if(param.size()>0)
				{
	
					for(int intK=0; intK<param.size(); intK++)
					{
						qryData1.setParameter(intK, param.get(intK));
					}
				}
			}
			
			
			list=qryData1.setFirstResult((page-1) * rows).setMaxResults(rows).list();	
			
			
			if(lgTotal % rows ==  0)
		    {
		    	totalpage =(int)(lgTotal/rows);
		    }
		    else
		    {
		    
		    	totalpage =((int) (lgTotal/rows) ) + 1;
		    }
		
		}		
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.find() Script error : "+ ex.toString());
		}
		
		return new Pagination(lgTotal,page,list,totalpage);
	}
	
	
	
	
	public T get(Class<T> c, Serializable id)
	{
		Session session = sessionFactory.getCurrentSession();
		
		T entity=(T)this.getCurrentSession().get(c, id);
		
		return entity;
	}
	
	
	
	public T get(String hql, Object[] param)
	{
		Session session = sessionFactory.getCurrentSession();
		
		List<T> list = this.find(hql, param);
		
		if(list != null)
		{
			if(list.size() > 0)
			{
				return list.get(0);
			}
			 
		}
		
		return null;
	}
	
	
	
	public T get(String hql, List<Object> param)
	{
		Session session = sessionFactory.getCurrentSession();
		
		List<T> list = this.find(hql, param);
		
		if(list != null)
		{
			if(list.size() > 0)
			{
				return list.get(0);
			}
			 
		}
		
		return null;
	}
	
	
	
	public List<T> getAll(Class<T> c)
	{
		Session session = sessionFactory.getCurrentSession();
		
		String strHQL = "";
		
		strHQL="from " + c.getName();
		
		List<T> list = this.find(strHQL);
				
		return null;
	}
	
	
	public int executeHql(String strHQL)
	{
		Session session = sessionFactory.getCurrentSession();
		
		Query  qryData=null;
		
		int intK=0;
		
		try
		{
			qryData= session.createQuery(strHQL);
			
			intK = qryData.executeUpdate();
			
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.executeHql() Script error: " + ex.toString());
		}
		
		
		return intK;
		
	}
	
	
	
	public int executeHql(String hql, Object[] param)
	{
		
		int intS = 0;
		
		Session session = sessionFactory.getCurrentSession();
		
		Query  qryData=null;
		
		try
		{
			qryData= session.createQuery(hql);			
		
			if(param != null)
			{
			
				if(param.length > 0)
				{
					for(int intK=0; intK<param.length; intK++)
					{
						qryData.setParameter(intK, param[intK]);
					}
				}
			}
			
			intS = qryData.executeUpdate();
			
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.executeHql() Script error: " + ex.toString());
		}
		
		return intS;
	}
	
	
	
	
	
	public int executeHql(String hql, List<Object> param)
	{
		Session session = sessionFactory.getCurrentSession();
		
		Query  qryData=null;
		
		int intS=0;
		
		try
		{
			qryData= session.createQuery(hql);					
		
			if(param != null)
			{
			
				if(param.size() > 0)
				{
					for(int intK=0; intK<param.size(); intK++)
					{
						qryData.setParameter(intK, param.get(intK));
					}
				}
			}
			
			intS=qryData.executeUpdate();
		
		}
		catch(Exception ex)
		{
			System.out.println("BaseDAOImpl.executeHql() Script error: " + ex.toString());
		}
		
		return intS;
	}	
	
	
}
