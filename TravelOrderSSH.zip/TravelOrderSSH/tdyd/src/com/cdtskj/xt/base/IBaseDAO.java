package com.cdtskj.xt.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import com.cdtskj.util.Pagination;


public interface IBaseDAO<T> 
{
	
		
	public Serializable save(T entity);
	
	public void update(T entity);
	
	public void delete(T entity);
	
	public void saveOrUpdate(T entity);
	
	
	
	public List<T>find(String hql);
	
	public List<T>find(String hql, Object[] param);
	
	public List<T>find(String hql, List<Object> param);
	
	
	
	public Pagination find(String hql,Object[] param,Integer page, Integer rows) throws Exception;
	
	public Pagination find(String hql,List<Object> param,Integer page, Integer rows) throws Exception;
	
	
	
	public T get(Class<T> c, Serializable id);
	
	public T get(String hql, Object[] param);
	
	public T get(String hql, List<Object> param);
	
	
	public List<T> getAll(Class<T> c);
	
	
	public int executeHql(String strHQL);
	
	public int executeHql(String hql, Object[] param);
	
	public int executeHql(String hql, List<Object> param);
	
	

}
