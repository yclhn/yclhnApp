package com.cdtskj.xt.log.action;

import java.util.List;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.util.Pagination;
import com.cdtskj.xt.log.service.ILogService;
import com.opensymphony.xwork2.ActionSupport;

public class LogAction extends ActionSupport
{
	
	private ILogService logService;
	
	private Integer logid;
	
	private String describes;	

	private String operator;
	
	private List<XtLog> list ;
	
	private XtLog log;
	
	
	private Integer pageno;
	
	private Integer totalpage;
	
	private Integer totalrow;
	
	private Integer pageSize;
	
	private Integer nextpage;
	
	private Integer prepage;
	 
	
	

	
	 


	public ILogService getLogService() 
	{
		return logService;
	}


	public void setLogService(ILogService logService) 
	{
		this.logService = logService;
	}


	public Integer getLogid() 
	{
		return logid;
	}


	public void setLogid(Integer logid) 
	{
		this.logid = logid;
	}


	public String getDescribes() 
	{
		return describes;
	}


	public void setDescribes(String describes) 
	{
		this.describes = describes;
	}


	public String getOperator() 
	{
		return operator;
	}


	public void setOperator(String operator) 
	{
		this.operator = operator;
	}


	public List<XtLog> getList() 
	{
		return list;
	}


	public void setList(List<XtLog> list) 
	{
		this.list = list;
	}


	public XtLog getLog() 
	{
		return log;
	}


	public void setLog(XtLog log) 
	{
		this.log = log;
	}


	public Integer getPageno() 
	{
		return pageno;
	}


	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}


	public Integer getTotalpage() 
	{
		return totalpage;
	}


	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}


	public Integer getTotalrow() 
	{
		return totalrow;
	}


	public void setTotalrow(Integer totalrow) 
	{
		this.totalrow = totalrow;
	}


	public Integer getNextpage() 
	{
		return nextpage;
	}


	public void setNextpage(Integer nextpage) 
	{
		this.nextpage = nextpage;
	}


	public Integer getPrepage() 
	{
		return prepage;
	}


	public void setPrepage(Integer prepage) 
	{
		this.prepage = prepage;
	}

		
	
	public String delete()
	{
		try
		{
			if(logid!=null)
			{				
				XtLog tempLog = new XtLog();
				
				tempLog.setLogid(logid);
				
				logService.deleteLog(tempLog);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("LogAction.delete() Script error : " + ex.toString());
			
		}
		
		return "list";
	}
	
	
	
	public String deleteall()
	{
		try
		{	
			logService.deleteAllLog();			 			
		
		}
		catch(Exception ex )
		{
			System.out.println("LogAction.deleteall() Script error : " + ex.toString());			
		}
		
		return "list";		
	}
	
	
	 
	 
	
	
	public String query()
	{
		try
		{
			XtLog tempLog = new XtLog();
			
			if(describes==null)
			{
				describes="";
			}
			
			tempLog.setDescribes(describes);
			
			
			
			if(operator==null)
			{
				operator="";
			}
			
			tempLog.setOperator(operator);			
			
			
			Pagination mypagi = logService.queryPaginationLog(tempLog, pageno, pageSize);
			
			
			
			if(mypagi != null)
			{				
				list=(List<XtLog>)mypagi.getRows();
				
				totalrow =Integer.parseInt( mypagi.getTotal().toString());
				
				totalpage = mypagi.getTotalpage();
				
				pageno = mypagi.getPage();
				
				if(pageno - 1 <= 0)
				{
					prepage = 1;
				}
				else
				{
					prepage = pageno - 1 ;
				}
				
				
				if(pageno + 1 > totalpage)
				{
					nextpage = totalpage;
				}
				else
				{
					nextpage = pageno + 1 ;
				}
				
			}			
			
		}
		catch(Exception ex)
		{
			System.out.println("LogAction.query() Script error: " + ex.toString());			
		}
		
		return "list";
	}
	

}
