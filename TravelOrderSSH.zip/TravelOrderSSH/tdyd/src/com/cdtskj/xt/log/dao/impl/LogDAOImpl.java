package com.cdtskj.xt.log.dao.impl;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.xt.base.BaseDAOImpl;
import com.cdtskj.xt.log.dao.ILogDAO;

public class LogDAOImpl extends BaseDAOImpl<XtLog> implements ILogDAO
{

}
