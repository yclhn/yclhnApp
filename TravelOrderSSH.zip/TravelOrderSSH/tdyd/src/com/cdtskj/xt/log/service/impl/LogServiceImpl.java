package com.cdtskj.xt.log.service.impl;

import org.hibernate.Transaction;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.util.HibernateUtil;
import com.cdtskj.util.Pagination;
import com.cdtskj.xt.log.dao.ILogDAO;
import com.cdtskj.xt.log.service.ILogService;

public class LogServiceImpl implements ILogService
{
	private ILogDAO dao;
	

	public ILogDAO getDao() 
	{
		return dao;
	}

	public void setDao(ILogDAO dao) 
	{
		this.dao = dao;
	}
	
	
	
	public void addLog(XtLog log)
	{
		try
		{			  			 
			 this.dao.save(log); 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("LogServiceImpl.addLog() Script error: " + ex.toString());
		}
		
	}
	
	
 
	
	public void deleteLog(XtLog log)
	{
		try
		{			
			 this.dao.delete(this.dao.get(XtLog.class, log.getLogid()));	 			 
		}
		catch(Exception ex)
		{
			System.out.println("LogServiceImpl.deleteLog() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public void deleteAllLog()
	{
		try
		{					 
			String strHQL="delete XtLog ";
			
			this.dao.executeHql(strHQL);
		
		}
		catch(Exception ex)
		{
			System.out.println("LogServiceImpl.deleteAllLog() Script error: " + ex.toString());
		}
		
	}
	
	
	
	public Pagination queryPaginationLog(XtLog log, Integer page, Integer rows)
	{
		 		
		Pagination mypagi = null;
		
		try
		{
			String strHQL = "from XtLog where  describes like ? AND operator like ? ";
			
			String[] param = new String [] {"%" + log.getDescribes() + "%" , "%" + log.getOperator() + "%"};
			
			mypagi = this.dao.find(strHQL, param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println("LogServiceImpl.queryPaginationLog() Script error: " + ex.toString());
		}			 
		
		return mypagi;
		
	}
		 

}
