package com.cdtskj.xt.user.action;

import java.util.List;

import com.cdtskj.pojo.LyAgency;
import com.cdtskj.pojo.XtUser;
import com.cdtskj.tdyd.agency.service.IAgencyService;
import com.cdtskj.util.Pagination;
import com.cdtskj.xt.user.service.IUserService;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport
{
	
	private IUserService userService;
	
	private IAgencyService agencyService;
	
	private List<LyAgency> listAgency;
	
	
	
	private Integer userid;
	
	private String name;	

	private String loginname;
	
	private List<XtUser> list ;
	
	private XtUser user;
	
	
	private Integer pageno;
	
	private Integer totalpage;
	
	private Integer totalrow;
	
	private Integer pageSize;
	
	private Integer nextpage;
	
	private Integer prepage;
	
	
	
	
	
	


	public IAgencyService getAgencyService() 
	{
		return agencyService;
	}


	public void setAgencyService(IAgencyService agencyService) 
	{
		this.agencyService = agencyService;
	}


	public List<LyAgency> getListAgency() 
	{
		return listAgency;
	}


	public void setListAgency(List<LyAgency> listAgency) 
	{
		this.listAgency = listAgency;
	}


	public IUserService getUserService() 
	{
		return userService;
	}


	public void setUserService(IUserService userService) 
	{
		this.userService = userService;
	}


	public Integer getUserid() 
	{
		return userid;
	}


	public void setUserid(Integer userid) 
	{
		this.userid = userid;
	}


	public String getName() 
	{
		return name;
	}


	public void setName(String name) 
	{
		this.name = name;
	}


	public String getLoginname() 
	{
		return loginname;
	}


	public void setLoginname(String loginname) 
	{
		this.loginname = loginname;
	}


	public List<XtUser> getList() 
	{
		return list;
	}


	public void setList(List<XtUser> list) 
	{
		this.list = list;
	}


	public XtUser getUser() 
	{
		return user;
	}


	public void setUser(XtUser user) 
	{
		this.user = user;
	}


	public Integer getPageno() 
	{
		return pageno;
	}


	public void setPageno(Integer pageno) 
	{
		this.pageno = pageno;
	}


	public Integer getTotalpage() 
	{
		return totalpage;
	}


	public void setTotalpage(Integer totalpage) 
	{
		this.totalpage = totalpage;
	}


	public Integer getTotalrow() 
	{
		return totalrow;
	}


	public void setTotalrow(Integer totalrow) 
	{
		this.totalrow = totalrow;
	}


	public Integer getNextpage() 
	{
		return nextpage;
	}


	public void setNextpage(Integer nextpage) 
	{
		this.nextpage = nextpage;
	}


	public Integer getPrepage() 
	{
		return prepage;
	}


	public void setPrepage(Integer prepage) 
	{
		this.prepage = prepage;
	}

	
	

	public String save()
	{
		if (user.getUserid()!=null)
		{
			userService.updateUser(user);
		}
		else
		{
			userService.addUser(user);
		}
		
		return "list";
	}
	
	
	
	
	public String delete()
	{
		try
		{
			if(userid!=null)
			{				
				XtUser tempUser = new XtUser();
				
				tempUser.setUserid(userid);
				
				userService.deleteUser(tempUser);
			}				
		
		}
		catch(Exception ex )
		{
			System.out.println("UserAction.delete() Script error : " + ex.toString());
			
		}
		
		return "list";
	}
	
	
	
	public String edit()
	{
		try
		{
			user = userService.queryUserById(userid);	
			
			listAgency = agencyService.querySuitableAgencys();
		}
		catch(Exception ex)
		{
			System.out.println("UserAction.edit() Script error : " + ex.toString());
		}
		
		return "data";
		
	}
	
	
	
	public String add()
	{
		try
		{						
			listAgency = agencyService.querySuitableAgencys();
		}
		catch(Exception ex)
		{
			System.out.println("UserAction.add() Script error : " + ex.toString());
		}
		
		return "data";
		
	}
	 
	
	
	public String query()
	{
		try
		{
			XtUser tempUser = new XtUser();
			
			if(loginname==null)
			{
				loginname="";
			}
			
			tempUser.setLoginname(loginname);
			
			if(name==null)
			{
				name="";
			}
			
			tempUser.setName(name);
			
			Pagination mypagi = userService.queryPaginationUser(tempUser, pageno, pageSize);
			
			if(mypagi != null)
			{				
				list=(List<XtUser>)mypagi.getRows();
				
				totalrow =Integer.parseInt( mypagi.getTotal().toString());
				
				totalpage = mypagi.getTotalpage();
				
				pageno = mypagi.getPage();
				
				if(pageno - 1 <= 0)
				{
					prepage = 1;
				}
				else
				{
					prepage = pageno - 1 ;
				}
				
				
				if(pageno + 1 > totalpage)
				{
					nextpage = totalpage;
				}
				else
				{
					nextpage = pageno + 1 ;
				}
				
			}			
			
		}
		catch(Exception ex)
		{
			System.out.println("UserAction.query() Script error: " + ex.toString());			
		}
				
		return "list";
		
	}
	

}
