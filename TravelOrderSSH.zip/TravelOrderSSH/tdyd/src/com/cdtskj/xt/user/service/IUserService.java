package com.cdtskj.xt.user.service;

import java.util.List;
import com.cdtskj.pojo.XtUser;
import com.cdtskj.util.Pagination;


public interface IUserService 
{
	 
	public List<XtUser> login(XtUser user);
	
	public void addUser(XtUser user);
	
	public void updateUser(XtUser user);
	
	public void deleteUser(XtUser user);
	
	
	
	public XtUser queryUserById(Integer id);		 
	
	public Pagination queryPaginationUser(XtUser User, Integer page, Integer rows);
	
}



