package com.cdtskj.xt.user.service.impl;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.Transaction;

import com.cdtskj.pojo.XtUser;
import com.cdtskj.util.HibernateUtil;
import com.cdtskj.util.Pagination;
import com.cdtskj.xt.user.dao.IUserDAO;
import com.cdtskj.xt.user.dao.impl.UserDAOImpl;
import com.cdtskj.xt.user.service.IUserService;

public class UserServiceImpl implements IUserService
{

	private IUserDAO dao ;
	
	

	public IUserDAO getDao() 
	{
		return dao;
	}

	public void setDao(IUserDAO dao) 
	{
		this.dao = dao;
	}
	
	
	
	
	public List<XtUser> login(XtUser user)
	{
		List<XtUser> list=null;		
		String strHQL="";		
		Object[] param =null; 
		
		
		try
		{		 
			
			strHQL = " from XtUser where loginname=? AND password=?";
		
			param = new Object[]{user.getLoginname(),user.getPassword()};
			
			list = this.dao.find(strHQL,param);						 
		
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.login() Script error : " + ex.toString());
		}
		
		
		return list;		
		
	}
	
	

	public void addUser(XtUser user)
	{
		try
		{
			
			 this.dao.save(user);	 			  		 
		}
		catch(Exception ex)
		{
			 System.out.println("UserServiceImpl.addUser() Script error: " + ex.toString());
		}
	}
	
	
	
	public void updateUser(XtUser user)  
	{				
		try
		{		 		 			 
			XtUser user2 = this.dao.get(XtUser.class, user.getUserid());
			
			BeanUtils.copyProperties(user2, user);
			
			this.dao.update(user2);	 			 		 
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.updateUser() Script error: " + ex.toString());
		}		 
		 
	}
	
	
	
	public void deleteUser(XtUser user)
	{
		try
		{			 			 
			 this.dao.delete(this.dao.get(XtUser.class, user.getUserid()));			 			  
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.deleteUser() Script error: " + ex.toString());
		}	
	}
	
	
	
	public XtUser queryUserById(Integer id)
	{ 
		 XtUser user=this.dao.get(XtUser.class, id);
		 
		 return user;
	}
		
	
	public Pagination queryPaginationUser(XtUser user, Integer page, Integer rows)
	{
		 
		
		Pagination mypagi = null;
		
		try
		{
			String strHQL = "from XtUser where name like ? AND loginname like ?";
			
			String[] param = new String [] {"%" + user.getName() + "%" , "%" + user.getLoginname() + "%"};
			
			mypagi = this.dao.find(strHQL, param, page, rows);
			
		}
		catch(Exception ex)
		{
			System.out.println("UserServiceImpl.queryPaginationUser() Script error: " + ex.toString());
		}		
		 
		
		return mypagi;
		
	}
	
		
}
