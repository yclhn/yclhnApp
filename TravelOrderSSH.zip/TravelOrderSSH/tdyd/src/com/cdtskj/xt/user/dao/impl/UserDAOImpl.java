package com.cdtskj.xt.user.dao.impl;

import com.cdtskj.pojo.XtUser;
import com.cdtskj.xt.base.BaseDAOImpl;
import com.cdtskj.xt.user.dao.IUserDAO;

public class UserDAOImpl extends BaseDAOImpl<XtUser> implements IUserDAO
{

}
