package com.cdtskj.util;

import java.util.Date;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;

import com.cdtskj.pojo.XtLog;
import com.cdtskj.pojo.XtUser;
import com.cdtskj.xt.log.service.ILogService;





public class LogAdvice 
{
	
	private static  Logger LOG =LogManager.getLogger(LogAdvice.class) ; 
	
	private ILogService logService;
	
	
	

	public ILogService getLogService() 
	{
		return logService;
	}

	public void setLogService(ILogService logService) 
	{
		this.logService = logService;
	}
	
	
	
	
	public void before(JoinPoint jp)
	{
		
		//1.Dim variable
		
		String arg = "";
		
		
		//2.Get all para
		
		Object [] args=jp.getArgs();
		
		if(args.length > 0)
		{
			
			for(int intK = 0; intK < args.length; intK++)
			{
				arg = arg + "Parameter" + (intK + 1) + ":" + "\n" ;
			}
			
		}
		else
		{
			arg = arg + "No parameter" ;
		}
		
		
		//3.Get request
		
		HttpServletRequest request = ServletActionContext.getRequest();
		
		
		//4.Get logon user
		
		XtUser user = (XtUser)request.getSession().getAttribute("user");
		
		
		//5.Get method name
		
		String methodName = jp.getSignature().getName();
		
		
		//6.Save log to DB
		
		if(Pattern.matches("(add|update|delete|login|apply|examine)[\\S]*", methodName))
		{
			
			if(user != null)
			{
				XtLog tempLog = new XtLog();
				
				tempLog.setDescribes(jp.getTarget().getClass() + "." + jp.getSignature().getName());
				
				tempLog.setDate(new Date());
				
				tempLog.setOperator(user.getLoginname());
				
				tempLog.setRemark("Write by Spring AOP test");
				
				logService.addLog(tempLog);
			}
			else
			{
				XtLog tempLog = new XtLog();
				
				tempLog.setDescribes("Logging System");
				
				tempLog.setDate(new Date());
				
				tempLog.setOperator(request.getParameter("user.loginname"));
				
				tempLog.setRemark("Write by Spring AOP test");
				
				logService.addLog(tempLog);
			}
			
		}
		
		
		//7.Write log (Log4j)
		
		String strLog="Before Advice-Method Execute : " + jp.getTarget().getClass() + "." + 
		jp.getSignature().getName() + "()\n" + arg;
		
		LOG.info( strLog);		
		
		
	}
	
	
	public Object arround(ProceedingJoinPoint jp) throws Throwable
	{
		
		//1.Get method
		
		String methodName = jp.getSignature().getName();
		
		
		//2.Get class
		
		String className = jp.getSignature().getDeclaringTypeName();
		
		className = className.substring(className.lastIndexOf(".") + 1).trim();
		
		
		//3.Save log to DB
		
		if(className.equals("LogServiceImpl"))
		{
			return jp.proceed();
		}
		 
		XtLog tempLog = new XtLog();
		
		tempLog.setDescribes("");
		
		tempLog.setDate(new Date());
		
		tempLog.setOperator("admin");
		
		tempLog.setRemark("Write by Spring AOP test");
		
		logService.addLog(tempLog);		
		
		return null;
		
	}
	
	
	
	public void afterThrowing(Throwable ex)
	{
		LOG.info("Error info: " + ex.getMessage());
		
		ex.printStackTrace();
	}
	

}
