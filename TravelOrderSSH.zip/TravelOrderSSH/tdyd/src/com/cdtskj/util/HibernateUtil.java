package com.cdtskj.util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 
public class HibernateUtil 
{
	public static final SessionFactory sessionFactory;
	
	private static String CONFIG_FILE="/config/hibernate.cfg.xml"; 
	
	static final Configuration CONFIGURATION;
	
	
	static
	{
		try
		{			
			CONFIGURATION = new Configuration();
			
			CONFIGURATION.configure(CONFIG_FILE);			
			
			sessionFactory = CONFIGURATION.buildSessionFactory();			
		}
		catch(Throwable ex)
		{
			System.out.println("HibernateUtil.static() Script error: " + ex.toString());
			
			throw new ExceptionInInitializerError(ex);
		}
	}
	
	
	public static Session getCurrentSession()
	{
		return sessionFactory.getCurrentSession();
	}
	
	
	public static Transaction beginTransaction()
	{
		Transaction trans=getCurrentSession().beginTransaction();
		
		return trans;
	}

}
